"""Offline tests for the diagnostic engine (no network needed).   Run: cd backend && python -m pytest -q"""
from v6scope.classify import classify

V6_OK_VANTAGE = {"v4": {"ok": True}, "v6": {"ok": True, "detail": "IPv6 connectivity confirmed"}}
NO_V6_VANTAGE = {"v4": {"ok": True}, "v6": {"ok": False, "detail": "operating system has no IPv6 stack"}}


def ok(fam, addr, status=200):
    return {"family": fam, "ok": True, "fail_stage": None,
            "dns": {"query": "A" if fam == 4 else "AAAA", "status": "OK", "addresses": [addr]},
            "attempts": [{"address": addr, "port": 443, "tcp": {"ok": True, "ms": 1},
                          "tls": {"ok": True, "version": "TLSv1.3", "cert": {"san": ["x.test"]}},
                          "http": {"ok": True, "status": status, "reason": "OK", "bytes": 10, "headers": {}}}],
            "consistent": True, "repeats": []}


def dns_fail(status):
    return {"family": 6, "ok": False, "fail_stage": "dns", "error_class": status, "error": status,
            "dns": {"query": "AAAA", "status": status, "addresses": []}, "attempts": [], "consistent": True}


def stage_fail(stage, ecls, consistent=True, http_status=None):
    a = {"address": "2001:db8::1", "port": 443, "tcp": {"ok": stage != "tcp", "error_class": ecls, "error": ecls},
         "tls": None, "http": None}
    if stage in ("tls", "http"):
        a["tls"] = {"ok": stage != "tls", "error_class": ecls, "error": ecls, "cert": {"san": ["wrong.example"]}}
    if stage == "http":
        a["http"] = {"ok": False, "status": http_status, "reason": "x", "error": f"HTTP {http_status}", "error_class": ecls}
    return {"family": 6, "ok": False, "fail_stage": stage, "error_class": ecls, "error": ecls,
            "dns": {"query": "AAAA", "status": "OK", "addresses": ["2001:db8::1"]}, "attempts": [a],
            "consistent": consistent, "repeats": [{"ok": False}]}


V4 = ok(4, "192.0.2.1")


def test_ipv6_ok():
    assert classify("u", V4, ok(6, "2001:db8::1"), V6_OK_VANTAGE)["ipv6_class"] == "IPv6_OK"


def test_no_aaaa_is_fail_dns_and_hidden():
    r = classify("u", V4, dns_fail("NODATA"), V6_OK_VANTAGE)
    assert (r["ipv6_class"], r["comparison"]) == ("FAIL_DNS", "hidden_v6_failure")


def test_no_aaaa_still_reported_without_v6_vantage():
    # a missing AAAA record is a DNS fact; it does not need IPv6 transport to prove
    assert classify("u", V4, dns_fail("NODATA"), NO_V6_VANTAGE)["ipv6_class"] == "FAIL_DNS"


def test_servfail_is_inconclusive():
    assert classify("u", V4, dns_fail("SERVFAIL"), V6_OK_VANTAGE)["ipv6_class"] == "INCONCLUSIVE"


def test_tcp_tls_http_failures():
    assert classify("u", V4, stage_fail("tcp", "ECONNREFUSED"), V6_OK_VANTAGE)["ipv6_class"] == "FAIL_TCP"
    assert classify("u", V4, stage_fail("tls", "CERT_NAME_MISMATCH"), V6_OK_VANTAGE)["ipv6_class"] == "FAIL_TLS"
    assert classify("u", V4, stage_fail("http", "HTTP_503", http_status=503), V6_OK_VANTAGE)["ipv6_class"] == "FAIL_HTTP"


def test_scanner_without_ipv6_never_blames_site():
    for st, e in (("tcp", "ENETUNREACH"), ("tls", "CERT_NAME_MISMATCH"), ("http", "HTTP_503")):
        assert classify("u", V4, stage_fail(st, e, http_status=503), NO_V6_VANTAGE)["ipv6_class"] == "INCONCLUSIVE"


def test_flaky_failure_is_inconclusive():
    assert classify("u", V4, stage_fail("tcp", "TIMEOUT", consistent=False), V6_OK_VANTAGE)["ipv6_class"] == "INCONCLUSIVE"


def test_same_http_error_on_both_is_parity():
    v4 = ok(4, "192.0.2.1", 403)
    v4["ok"] = False
    v4["fail_stage"] = "http"
    v4["attempts"][0]["http"].update(ok=False, status=403)
    r = classify("u", v4, stage_fail("http", "HTTP_403", http_status=403), V6_OK_VANTAGE)
    assert r["ipv6_class"] == "IPv6_OK" and r["comparison"] == "parity_ok"
