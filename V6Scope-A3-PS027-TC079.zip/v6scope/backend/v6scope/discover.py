"""Dependency discovery with a real browser, viewed separately "as an IPv4-only user" and
"as an IPv6-only user".

How the per-protocol browser views work
---------------------------------------
Chromium's --host-resolver-rules lets us decide, per hostname, which IP the browser uses.
For the IPv4 view every host is mapped to one of its A records; for the IPv6 view to one of
its AAAA records; hosts with no record of that family are mapped to ~NOTFOUND, and every
host we have not resolved yet is also ~NOTFOUND. A page often pulls in hosts we cannot know
in advance (fonts referenced from CSS, scripts injected by scripts), so we iterate: load the
page, collect the new hostnames from the requests it tried to make, resolve them with
V6Scope's own per-family resolver, relaunch, until no new host appears.

Chromium still does the real work (HTML/CSS/JS, TCP, TLS with certificate checks, HTTP),
so the IPv6 view shows what an IPv6-only visitor would actually experience. QUIC and any
proxy are disabled so the browser uses plain TCP straight to the chosen address.
"""
from __future__ import annotations

import os
import re
import time
import urllib.request
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit, urldefrag

from .config import Settings
from .resolver import FamilyResolver, OK

MAX_ITER = 4


def _norm(url: str) -> str:
    return urldefrag(url)[0]


def _rule_addr(addr: str) -> str:
    return f"[{addr}]" if ":" in addr else addr


class BrowserUnavailable(Exception):
    pass


def browser_view(url: str, family: int, s: Settings, resolver: FamilyResolver,
                 shot_path: str | None, log=print) -> dict:
    try:
        from playwright.sync_api import sync_playwright, Error as PWError
    except Exception as e:  # pragma: no cover
        raise BrowserUnavailable(str(e))

    known: dict[str, str | None] = {}

    def learn(host: str):
        d = resolver.resolve(host, family)
        known[host] = d["addresses"][0] if d["status"] == OK and d["addresses"] else None

    learn(urlsplit(url).hostname)
    env = dict(os.environ)
    if s.browser_home:
        env["HOME"] = s.browser_home
    for k in ("HTTPS_PROXY", "HTTP_PROXY", "https_proxy", "http_proxy", "ALL_PROXY", "all_proxy"):
        env.pop(k, None)

    view = {"family": family, "iterations": 0, "requests": {}, "page_error": None,
            "load_ms": None, "screenshot": None, "hosts": {}}
    with sync_playwright() as p:
        for it in range(MAX_ITER):
            view["iterations"] = it + 1
            rules = [f"MAP {h} {_rule_addr(a)}" if a else f"MAP {h} ~NOTFOUND" for h, a in known.items()]
            rules.append("MAP * ~NOTFOUND")
            browser = p.chromium.launch(env=env, args=[
                "--host-resolver-rules=" + ", ".join(rules), "--disable-quic",
                "--no-proxy-server", "--disable-features=AsyncDns",
                "--disable-background-networking"])
            ctx = browser.new_context(viewport={"width": 1280, "height": 900},
                                      user_agent=None, service_workers="block")
            page = ctx.new_page()
            reqs: dict[str, dict] = {}

            def on_req(r):
                u = _norm(r.url)
                if not u.startswith(("http://", "https://")):
                    return
                reqs.setdefault(u, {"url": u, "type": r.resource_type, "status": None,
                                    "error": None, "referer": r.headers.get("referer"),
                                    "frame": r.frame.url if r.frame else None, "method": r.method})

            def on_resp(resp):
                u = _norm(resp.url)
                if u in reqs:
                    reqs[u]["status"] = resp.status

            def on_fail(r):
                u = _norm(r.url)
                if u in reqs:
                    reqs[u]["error"] = r.failure or "failed"

            page.on("request", on_req)
            page.on("response", on_resp)
            page.on("requestfailed", on_fail)
            t0 = time.perf_counter()
            try:
                page.goto(url, wait_until="load", timeout=s.page_timeout_ms)
                view["page_error"] = None
            except PWError as e:
                view["page_error"] = str(e).split("\n")[0][:300]
            try:
                page.wait_for_load_state("networkidle", timeout=6000)
            except PWError:
                pass
            try:  # trigger lazy-loaded content
                page.evaluate("window.scrollTo(0, document.body ? document.body.scrollHeight : 0)")
                page.wait_for_timeout(1200)
            except PWError:
                pass
            view["load_ms"] = round((time.perf_counter() - t0) * 1000)
            new_hosts = {urlsplit(u).hostname for u in reqs} - set(known) - {None}
            if not new_hosts or it == MAX_ITER - 1:
                if shot_path:
                    try:
                        page.screenshot(path=shot_path, full_page=True)
                        view["screenshot"] = shot_path
                    except PWError:
                        pass
                view["requests"] = reqs
                browser.close()
                break
            log(f"  IPv{family} view: found {len(new_hosts)} new host(s) {sorted(new_hosts)}, re-resolving")
            for h in new_hosts:
                learn(h)
            browser.close()
    view["hosts"] = known
    return view


# ----------------------------------------------------------------- static fallback
class _Links(HTMLParser):
    ATTRS = {"src", "href", "data-src", "poster"}

    def __init__(self, base):
        super().__init__()
        self.base, self.found = base, []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "a":
            return  # navigation links are not page dependencies
        if tag == "link" and (a.get("rel") or "").lower() in ("canonical", "alternate", "next", "prev"):
            return
        for k in self.ATTRS:
            if a.get(k):
                self.found.append((tag, urljoin(self.base, a[k])))
        if a.get("srcset"):
            for part in a["srcset"].split(","):
                if part.strip():
                    self.found.append((tag, urljoin(self.base, part.strip().split()[0])))
        if a.get("style"):
            for m in re.findall(r"url\(['\"]?([^'\")]+)", a["style"]):
                self.found.append(("css-url", urljoin(self.base, m)))


def static_discover(url: str, s: Settings) -> list[dict]:
    req = urllib.request.Request(url, headers={"User-Agent": s.user_agent})
    html = urllib.request.urlopen(req, timeout=15).read(2_000_000).decode("utf-8", "replace")
    p = _Links(url)
    p.feed(html)
    out = {}
    for tag, u in p.found:
        u = _norm(u)
        if u.startswith(("http://", "https://")):
            t = {"script": "script", "img": "image", "link": "stylesheet" if u.endswith(".css") else "other",
                 "css-url": "image"}.get(tag, "other")
            out.setdefault(u, {"url": u, "type": t, "referer": url})
    return list(out.values())


def discover(url: str, s: Settings, resolver: FamilyResolver, scan_id: str, log=print) -> dict:
    os.makedirs(s.artifacts_dir, exist_ok=True)
    result = {"method": None, "views": {}, "resources": {}, "notes": []}
    resources: dict[str, dict] = {_norm(url): {"url": _norm(url), "type": "document", "referer": None,
                                               "seen_in": [], "browser": {}}}
    if s.browser:
        try:
            for fam in (4, 6):
                log(f"Browser view as an IPv{fam}-only client …")
                shot = os.path.join(s.artifacts_dir, f"{scan_id}_v{fam}.png")
                v = browser_view(url, fam, s, resolver, shot, log=log)
                reqs = v.pop("requests")
                v["request_count"] = len(reqs)
                v["failed_count"] = sum(1 for r in reqs.values() if r["error"] or (r["status"] or 0) >= 400)
                result["views"][f"v{fam}"] = v
                for u, r in reqs.items():
                    ent = resources.setdefault(u, {"url": u, "type": r["type"], "referer": r["referer"],
                                                   "seen_in": [], "browser": {}})
                    if ent["type"] in (None, "other") and r["type"]:
                        ent["type"] = r["type"]
                    if not ent.get("referer") and r["referer"]:
                        ent["referer"] = r["referer"]
                    ent["seen_in"].append(f"v{fam}")
                    ent["browser"][f"v{fam}"] = {"status": r["status"], "error": r["error"]}
            result["method"] = "browser (Chromium via Playwright, IPv4-only and IPv6-only views)"
        except BrowserUnavailable as e:
            result["notes"].append(f"Browser unavailable ({e}); used static HTML discovery.")
        except Exception as e:
            result["notes"].append(f"Browser discovery error: {type(e).__name__}: {str(e)[:200]}; used static HTML discovery.")
    if not result["method"]:
        try:
            for r in static_discover(url, s):
                ent = resources.setdefault(r["url"], {**r, "seen_in": [], "browser": {}})
                ent["seen_in"].append("static")
            result["method"] = "static HTML parsing (fallback)"
        except Exception as e:
            result["notes"].append(f"Static discovery failed: {e}")
            result["method"] = "target URL only"
    result["resources"] = list(resources.values())[: s.max_resources]
    if len(resources) > s.max_resources:
        result["notes"].append(f"Resource list truncated to {s.max_resources} of {len(resources)}.")
    return result
