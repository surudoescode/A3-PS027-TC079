"""Per-family DNS resolution.

IPv4 and IPv6 are resolved *separately*: an A query for the IPv4 path and an AAAA query
for the IPv6 path. We keep the exact DNS outcome because the difference matters:

  NODATA   - the name exists but has no record of this type (e.g. no AAAA) -> real gap
  NXDOMAIN - the name does not exist at all (not an IPv6-specific problem)
  SERVFAIL / TIMEOUT - the resolver could not answer; absence is NOT proven (RFC 4074
             documents servers that mishandle AAAA queries) -> inconclusive
"""
from __future__ import annotations

import ipaddress
import socket
import threading
import time

import dns.exception
import dns.flags
import dns.rdatatype
import dns.resolver

from .config import Settings

OK, NODATA, NXDOMAIN, SERVFAIL, TIMEOUT, ERROR, LITERAL_MISMATCH = (
    "OK", "NODATA", "NXDOMAIN", "SERVFAIL", "TIMEOUT", "ERROR", "LITERAL_MISMATCH")


class FamilyResolver:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._cache: dict[tuple[str, int], dict] = {}
        self._lock = threading.Lock()
        self._resolver = self._build(settings.nameserver)
        self._lab = self._build(settings.lab_nameserver) if settings.lab_nameserver else None

    def _build(self, nameserver: str):
        s = self.settings
        try:
            if nameserver:
                r = dns.resolver.Resolver(configure=False)
                host, _, port = nameserver.rpartition(":") if nameserver.count(":") == 1 else (nameserver, "", "53")
                r.nameservers = [host]
                r.port = int(port or 53)
            else:
                r = dns.resolver.Resolver(configure=True)
            r.timeout = s.dns_timeout
            r.lifetime = s.dns_timeout * 2
            return r
        except Exception:
            return None  # no resolv.conf: fall back to getaddrinfo

    def _pick(self, host: str):
        z = self.settings.lab_zone.lower()
        if self._lab is not None and z and (host == z or host.endswith("." + z)):
            return self._lab
        return self._resolver

    def describe(self, host: str = "") -> str:
        r = self._pick(host.lower()) if host else self._resolver
        if r is None:
            return "system getaddrinfo()"
        ns = ",".join(str(x) for x in r.nameservers)
        out = f"DNS {ns} port {r.port}"
        if not host and self._lab is not None:
            lab = ",".join(str(x) for x in self._lab.nameservers)
            out += f" (+ {self.settings.lab_zone} → {lab}:{self._lab.port})"
        return out

    def resolve(self, host: str, family: int) -> dict:
        key = (host.lower(), family)
        with self._lock:
            if key in self._cache:
                return self._cache[key]
        res = self._resolve(host, family)
        with self._lock:
            self._cache[key] = res
        return res

    def _resolve(self, host: str, family: int) -> dict:
        rtype = "A" if family == 4 else "AAAA"
        t0 = time.perf_counter()
        out = {"family": family, "query": rtype, "host": host, "status": ERROR,
               "addresses": [], "cnames": [], "rcode": None, "error": None, "ms": None,
               "server": self.describe(host)}
        # IP literals in URLs (e.g. https://203.0.113.5/x.js) never touch DNS
        try:
            ip = ipaddress.ip_address(host.strip("[]"))
            if ip.version == family:
                out.update(status=OK, addresses=[str(ip)], rcode="LITERAL")
            else:
                out.update(status=LITERAL_MISMATCH, rcode="LITERAL",
                           error=f"URL uses a hard-coded IPv{ip.version} address literal; "
                                 f"there is no IPv{family} equivalent")
            out["ms"] = 0.0
            return out
        except ValueError:
            pass

        resolver = self._pick(host.lower())
        if resolver is None:
            return self._via_getaddrinfo(host, family, out, t0)
        try:
            ans = resolver.resolve(host, rtype, raise_on_no_answer=False, search=False)
            out["rcode"] = "NOERROR"
            for rrset in ans.response.answer:
                if rrset.rdtype == dns.rdatatype.CNAME:
                    out["cnames"] += [r.target.to_text().rstrip(".") for r in rrset]
            if ans.rrset is None or len(ans.rrset) == 0:
                out.update(status=NODATA, error=f"name exists but has no {rtype} record")
            else:
                out.update(status=OK, addresses=[r.address for r in ans.rrset],
                           ttl=ans.rrset.ttl)
        except dns.resolver.NXDOMAIN:
            out.update(status=NXDOMAIN, rcode="NXDOMAIN", error="name does not exist (NXDOMAIN)")
        except dns.resolver.NoNameservers as e:
            out.update(status=SERVFAIL, rcode="SERVFAIL",
                       error=f"resolver could not answer the {rtype} query (SERVFAIL): {str(e)[:160]}")
        except (dns.resolver.LifetimeTimeout, dns.exception.Timeout):
            out.update(status=TIMEOUT, rcode="TIMEOUT", error=f"{rtype} query timed out")
        except Exception as e:  # pragma: no cover - defensive
            out.update(status=ERROR, error=f"{type(e).__name__}: {e}")
        out["ms"] = round((time.perf_counter() - t0) * 1000, 1)
        return out

    def _via_getaddrinfo(self, host, family, out, t0):
        fam = socket.AF_INET if family == 4 else socket.AF_INET6
        try:
            infos = socket.getaddrinfo(host, 443, fam, socket.SOCK_STREAM)
            addrs = list(dict.fromkeys(i[4][0] for i in infos))
            out.update(status=OK, addresses=addrs, rcode="NOERROR")
        except socket.gaierror as e:
            if e.errno in (socket.EAI_NONAME,):
                out.update(status=NXDOMAIN, error=str(e))
            elif getattr(socket, "EAI_NODATA", None) == e.errno:
                out.update(status=NODATA, error=str(e))
            elif e.errno == socket.EAI_AGAIN:
                out.update(status=TIMEOUT, error=str(e))
            else:
                out.update(status=ERROR, error=str(e))
        out["ms"] = round((time.perf_counter() - t0) * 1000, 1)
        return out
