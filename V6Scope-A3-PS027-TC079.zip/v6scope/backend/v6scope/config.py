"""Runtime settings for V6Scope, read from environment variables.

Every knob has a safe default so `uvicorn v6scope.api:app` works out of the box.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _env_list(name: str, default: str) -> list[str]:
    raw = os.environ.get(name, default)
    return [x.strip() for x in raw.split(",") if x.strip()]


@dataclass
class Settings:
    # SQLite database file holding scan history and results
    db_path: str = os.environ.get("V6SCOPE_DB", str(ROOT / "data" / "v6scope.db"))
    # Where browser screenshots are written
    artifacts_dir: str = os.environ.get("V6SCOPE_ARTIFACTS", str(ROOT / "data" / "artifacts"))
    # Optional explicit DNS server "ip[:port]". Empty = use the system resolver
    # (/etc/resolv.conf). The controlled lab sets this to its own DNS server.
    nameserver: str = os.environ.get("V6SCOPE_NAMESERVER", "")
    # Split DNS for the controlled lab: names under lab_zone go to lab_nameserver,
    # everything else to the normal resolver. Lets one deployment scan both.
    lab_zone: str = os.environ.get("V6SCOPE_LAB_ZONE", "v6lab.test")
    lab_nameserver: str = os.environ.get("V6SCOPE_LAB_NAMESERVER", "")
    # Extra CA bundle to trust in addition to the system store (the lab CA).
    extra_ca: str = os.environ.get("V6SCOPE_EXTRA_CA", "")
    dns_timeout: float = float(os.environ.get("V6SCOPE_DNS_TIMEOUT", "3"))
    connect_timeout: float = float(os.environ.get("V6SCOPE_CONNECT_TIMEOUT", "4"))
    tls_timeout: float = float(os.environ.get("V6SCOPE_TLS_TIMEOUT", "5"))
    http_timeout: float = float(os.environ.get("V6SCOPE_HTTP_TIMEOUT", "8"))
    # How many addresses per family to try for one host
    max_addrs: int = int(os.environ.get("V6SCOPE_MAX_ADDRS", "2"))
    # Failed probes are repeated this many times; disagreeing repeats => INCONCLUSIVE
    retries: int = int(os.environ.get("V6SCOPE_RETRIES", "1"))
    max_resources: int = int(os.environ.get("V6SCOPE_MAX_RESOURCES", "150"))
    workers: int = int(os.environ.get("V6SCOPE_WORKERS", "12"))
    # Vantage-point self-test targets ("host:port"). If none of the IPv6 anchors can be
    # reached, IPv6 transport failures are reported as INCONCLUSIVE, never as FAIL.
    v6_anchors: list[str] = field(default_factory=lambda: _env_list(
        "V6SCOPE_V6_ANCHORS", "www.google.com:443,one.one.one.one:443,www.cloudflare.com:443"))
    v4_anchors: list[str] = field(default_factory=lambda: _env_list(
        "V6SCOPE_V4_ANCHORS", "www.google.com:443,one.one.one.one:443,www.cloudflare.com:443"))
    # Real-browser discovery (Playwright/Chromium). Falls back to static HTML parsing.
    browser: bool = os.environ.get("V6SCOPE_BROWSER", "1") == "1"
    # HOME used for Chromium (its NSS certificate DB lives there; the lab CA is added to it)
    browser_home: str = os.environ.get("V6SCOPE_BROWSER_HOME", "")
    page_timeout_ms: int = int(os.environ.get("V6SCOPE_PAGE_TIMEOUT_MS", "25000"))
    user_agent: str = "V6Scope/1.0 (+IPv6 dependency readiness auditor; AIORI-3 PS-027)"


settings = Settings()
