"""CSV and JSON report builders."""
from __future__ import annotations

import csv
import io
import json


def _stage(r: dict, key: str):
    a = (r.get("attempts") or [{}])[-1]
    v = a.get(key) or {}
    return v


def json_report(scan: dict) -> str:
    out = {
        "tool": "V6Scope — IPv6 Website and Dependency Readiness Auditor (AIORI-3 PS-027, team V6ision)",
        "scan": {k: scan.get(k) for k in ("id", "batch_id", "url", "status", "created_at", "started_at",
                                          "finished_at", "summary", "vantage", "discovery", "error")},
        "resources": [{k: r.get(k) for k in ("url", "host", "port", "scheme", "rtype", "party", "referer",
                                             "seen_in", "browser", "ipv6_class", "comparison", "confidence",
                                             "diagnosis", "v4", "v6")} for r in scan["resources"]],
    }
    return json.dumps(out, indent=2, default=str)


CSV_COLS = ["url", "host", "type", "party", "ipv6_class", "comparison", "confidence",
            "v4_dns", "v4_addresses", "v4_tcp", "v4_tls", "v4_http_status", "v4_fail_stage",
            "v6_dns", "v6_addresses", "v6_tcp", "v6_tls", "v6_http_status", "v6_fail_stage", "v6_error",
            "browser_v4", "browser_v6", "diagnosis", "likely_cause", "recommended_fix"]


def csv_report(scan: dict) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["# V6Scope report", scan["url"], scan["id"], scan.get("finished_at")])
    w.writerow(CSV_COLS)
    for r in scan["resources"]:
        row = {"url": r["url"], "host": r["host"], "type": r["rtype"], "party": r["party"],
               "ipv6_class": r["ipv6_class"], "comparison": r["comparison"], "confidence": r["confidence"]}
        for fam in ("v4", "v6"):
            p = r.get(fam) or {}
            d = p.get("dns") or {}
            row[f"{fam}_dns"] = d.get("status")
            row[f"{fam}_addresses"] = " ".join(d.get("addresses", []))
            t = _stage(p, "tcp")
            row[f"{fam}_tcp"] = ("ok" if t.get("ok") else t.get("error_class")) if t else ""
            tl = _stage(p, "tls")
            row[f"{fam}_tls"] = ("ok" if tl.get("ok") else tl.get("error_class")) if tl else ""
            h = _stage(p, "http")
            row[f"{fam}_http_status"] = h.get("status", "")
            row[f"{fam}_fail_stage"] = p.get("fail_stage") or ""
        row["v6_error"] = (r.get("v6") or {}).get("error") or ""
        b = r.get("browser") or {}
        for fam in ("v4", "v6"):
            x = b.get(fam) or {}
            row[f"browser_{fam}"] = x.get("error") or (x.get("status") if x else "")
        dg = r.get("diagnosis") or {}
        row["diagnosis"], row["likely_cause"], row["recommended_fix"] = dg.get("title"), dg.get("cause"), dg.get("fix")
        w.writerow([row.get(c, "") for c in CSV_COLS])
    return buf.getvalue()
