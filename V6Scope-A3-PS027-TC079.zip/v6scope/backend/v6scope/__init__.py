"""V6Scope — IPv6 Website and Dependency Readiness Auditor (AIORI-3 PS-027)."""
__version__ = "1.0.0"
