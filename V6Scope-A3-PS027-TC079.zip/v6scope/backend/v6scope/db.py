"""SQLite persistence: scan history, per-resource results with full evidence."""
from __future__ import annotations

import json
import os
import sqlite3
import threading

SCHEMA = """
CREATE TABLE IF NOT EXISTS scans (
    id          TEXT PRIMARY KEY,
    batch_id    TEXT NOT NULL,
    url         TEXT NOT NULL,
    label       TEXT,
    status      TEXT NOT NULL,            -- queued | running | done | error
    progress    TEXT,
    created_at  TEXT NOT NULL,
    started_at  TEXT,
    finished_at TEXT,
    vantage     TEXT,                     -- JSON: scanner self-test (IPv4/IPv6 capability)
    discovery   TEXT,                     -- JSON: method, browser views, notes
    summary     TEXT,                     -- JSON: counts, rates, class breakdown
    error       TEXT
);
CREATE TABLE IF NOT EXISTS resources (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id     TEXT NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
    url         TEXT NOT NULL,
    host        TEXT NOT NULL,
    port        INTEGER,
    scheme      TEXT,
    rtype       TEXT,                     -- document, stylesheet, script, image, font, fetch …
    party       TEXT,                     -- first | third
    referer     TEXT,                     -- which page/stylesheet pulled it in (dependency edge)
    seen_in     TEXT,                     -- JSON list of discovery views
    browser     TEXT,                     -- JSON: what Chromium saw in each view
    v4          TEXT,                     -- JSON: full IPv4 staged probe
    v6          TEXT,                     -- JSON: full IPv6 staged probe
    ipv6_class  TEXT NOT NULL,            -- IPv6_OK | FAIL_DNS | FAIL_TCP | FAIL_TLS | FAIL_HTTP | INCONCLUSIVE
    comparison  TEXT,                     -- parity_ok | hidden_v6_failure | both_fail | v4_only_failure | inconclusive
    confidence  TEXT,
    diagnosis   TEXT                      -- JSON: title, cause, explanation, fix, evidence, ladder
);
CREATE INDEX IF NOT EXISTS idx_res_scan ON resources(scan_id);
CREATE INDEX IF NOT EXISTS idx_scans_batch ON scans(batch_id);
"""

_lock = threading.Lock()


class DB:
    def __init__(self, path: str):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self.path = path
        with self.conn() as c:
            c.executescript(SCHEMA)

    def conn(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        return c

    def execute(self, sql, args=()):
        with _lock, self.conn() as c:
            c.execute(sql, args)

    def insert_scan(self, **kw):
        cols = ",".join(kw)
        self.execute(f"INSERT INTO scans ({cols}) VALUES ({','.join('?' * len(kw))})", tuple(kw.values()))

    def update_scan(self, scan_id, **kw):
        kw = {k: (json.dumps(v) if isinstance(v, (dict, list)) else v) for k, v in kw.items()}
        sets = ",".join(f"{k}=?" for k in kw)
        self.execute(f"UPDATE scans SET {sets} WHERE id=?", (*kw.values(), scan_id))

    def insert_resources(self, rows: list[dict]):
        if not rows:
            return
        cols = list(rows[0])
        with _lock, self.conn() as c:
            c.executemany(f"INSERT INTO resources ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})",
                          [tuple(json.dumps(r[k]) if isinstance(r[k], (dict, list)) else r[k] for k in cols)
                           for r in rows])

    @staticmethod
    def _decode(row, fields):
        d = dict(row)
        for f in fields:
            if d.get(f):
                try:
                    d[f] = json.loads(d[f])
                except Exception:
                    pass
        return d

    def list_scans(self, limit=200):
        with self.conn() as c:
            rows = c.execute("SELECT id,batch_id,url,label,status,progress,created_at,finished_at,summary,error,vantage "
                             "FROM scans ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return [self._decode(r, ["summary", "vantage"]) for r in rows]

    def get_scan(self, scan_id):
        with self.conn() as c:
            s = c.execute("SELECT * FROM scans WHERE id=?", (scan_id,)).fetchone()
            if not s:
                return None
            res = c.execute("SELECT * FROM resources WHERE scan_id=? ORDER BY id", (scan_id,)).fetchall()
        scan = self._decode(s, ["vantage", "discovery", "summary"])
        scan["resources"] = [self._decode(r, ["seen_in", "browser", "v4", "v6", "diagnosis"]) for r in res]
        return scan

    def delete_scan(self, scan_id):
        self.execute("DELETE FROM scans WHERE id=?", (scan_id,))
