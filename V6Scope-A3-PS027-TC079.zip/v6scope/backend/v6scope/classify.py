"""Diagnostic engine: compare the IPv4 and IPv6 results for one resource and decide.

Output classes (PS-027): IPv6_OK, FAIL_DNS, FAIL_TCP, FAIL_TLS, FAIL_HTTP, INCONCLUSIVE.

Guard-rails against false conclusions:
  * the scanner itself has no working IPv6        -> INCONCLUSIVE (not the site's fault)
  * the failure did not repeat the same way        -> INCONCLUSIVE (flaky / transient)
  * AAAA lookup SERVFAIL / timeout                 -> INCONCLUSIVE (absence not proven)
  * name does not exist on either family           -> INCONCLUSIVE (not IPv6-specific)
"""
from __future__ import annotations

CLASSES = ["IPv6_OK", "FAIL_DNS", "FAIL_TCP", "FAIL_TLS", "FAIL_HTTP", "INCONCLUSIVE"]


def _first_attempt(r: dict) -> dict:
    return (r.get("attempts") or [{}])[-1] if r else {}


def _stage_summary(r: dict) -> dict:
    """Compact per-stage pass/fail for the UI ladder."""
    out = {}
    d = r.get("dns") or {}
    out["dns"] = "ok" if d.get("status") == "OK" else "fail"
    if out["dns"] == "fail":
        return out | {"tcp": "skip", "tls": "skip", "http": "skip"}
    a = _first_attempt(r)
    for st in ("tcp", "tls", "http"):
        v = a.get(st)
        out[st] = "skip" if v is None else ("ok" if v.get("ok") else "fail")
    if a.get("tls") is None and out["tcp"] == "ok":
        out["tls"] = "n/a"
    return out


def classify(url: str, v4: dict, v6: dict, vantage: dict) -> dict:
    v6_capable = bool(vantage.get("v6", {}).get("ok"))
    v4_ok = bool(v4.get("ok"))
    ev: list[str] = []
    res = {"ipv6_class": None, "comparison": None, "confidence": None,
           "title": None, "cause": None, "explanation": None, "fix": None, "evidence": ev,
           "ladder": {"v4": _stage_summary(v4), "v6": _stage_summary(v6)}}

    def evidence_for(r, fam):
        d = r.get("dns") or {}
        ev.append(f"IPv{fam} DNS {d.get('query')} → {d.get('status')}"
                  + (f" {', '.join(d.get('addresses', [])[:3])}" if d.get("addresses") else "")
                  + (f" (via CNAME {' → '.join(d['cnames'])})" if d.get("cnames") else ""))
        for a in r.get("attempts", []):
            t = a.get("tcp") or {}
            line = f"IPv{fam} TCP [{a['address']}]:{a['port']} → " + ("connected" if t.get("ok") else t.get("error", "?"))
            if t.get("ms") is not None:
                line += f" ({t['ms']} ms)"
            ev.append(line)
            if a.get("tls"):
                tl = a["tls"]
                c = tl.get("cert") or {}
                names = ", ".join((c.get("san") or [])[:4]) or c.get("subject_cn") or "?"
                ev.append(f"IPv{fam} TLS → " + (f"{tl.get('version')} OK, cert for {names}" if tl.get("ok")
                          else f"{tl.get('error')}; certificate presented covers: {names}"))
            if a.get("http"):
                h = a["http"]
                ev.append(f"IPv{fam} HTTP → " + (f"{h.get('status')} {h.get('reason','')}, {h.get('bytes')} bytes"
                          if "status" in h else h.get("error", "?"))
                          + (f", server: {h['headers']['server']}" if h.get("headers", {}).get("server") else ""))
        if r.get("repeats"):
            ev.append(f"IPv{fam} repeat test: " + "; ".join(
                ("OK" if x.get("ok") else f"{x.get('fail_stage')}:{x.get('error_class')}") for x in r["repeats"]))

    evidence_for(v4, 4)
    evidence_for(v6, 6)

    def done(cls, comparison, conf, title, cause, expl, fix):
        res.update(ipv6_class=cls, comparison=comparison, confidence=conf, title=title,
                   cause=cause, explanation=expl, fix=fix)
        return res

    if v6.get("ok"):
        cmp_ = "parity_ok" if v4_ok else "v4_only_failure"
        note = None if v4_ok else "Works over IPv6 but NOT over IPv4 (IPv4 failed at " + str(v4.get("fail_stage")) + ")."
        if v6.get("partial"):
            note = (note + " " if note else "") + "Partial: " + v6["partial"]
        return done("IPv6_OK", cmp_, "high", "Reachable over IPv6",
                    "All four stages (DNS, TCP, TLS, HTTP) succeeded over IPv6.", note, None)

    stage, ecls = v6.get("fail_stage"), v6.get("error_class")
    hidden = v4_ok
    comparison = "hidden_v6_failure" if hidden else "both_fail"
    v6_dns = v6.get("dns") or {}

    # ---------------------------------------------------------------- DNS stage
    if stage == "dns":
        if ecls == "NODATA" and (v4.get("dns") or {}).get("status") == "OK":
            return done("FAIL_DNS", comparison, "high", "No IPv6 address (AAAA) published",
                        "The hostname has an A record but its AAAA query returned NOERROR with no data.",
                        "IPv6-only clients cannot even find a server for this resource. Over IPv4 it "
                        + ("loads normally, so the failure is invisible to anyone testing from an IPv4 or dual-stack network."
                           if hidden else "also fails, so this resource is broken more generally."),
                        "Publish an AAAA record (enable IPv6 on the hosting provider / CDN for this hostname), "
                        "or serve the resource from an IPv6-enabled host.")
        if ecls == "LITERAL_MISMATCH":
            return done("FAIL_DNS", comparison, "high", "Hard-coded IPv4 address in the URL",
                        v6.get("error"), "An IPv4 address literal can never be reached by an IPv6-only client.",
                        "Reference the resource by hostname with both A and AAAA records.")
        if ecls in ("SERVFAIL", "TIMEOUT", "ERROR"):
            return done("INCONCLUSIVE", "inconclusive", "low", "AAAA lookup failed — absence not proven",
                        f"The resolver returned {ecls} for the AAAA query ({v6_dns.get('error')}).",
                        "A broken answer is not the same as 'no IPv6'. Some authoritative servers mishandle AAAA "
                        "queries (RFC 4074); the failure may also be in the resolver. V6Scope will not guess.",
                        "Re-test from another resolver; check the authoritative DNS servers' handling of AAAA queries.")
        if ecls == "NXDOMAIN":
            return done("INCONCLUSIVE", "inconclusive" if not hidden else comparison, "low",
                        "Name does not exist",
                        "The hostname returned NXDOMAIN.", "This is not specific to IPv6.", "Fix the hostname or DNS zone.")

    # --------------------------------------------- transport stages need a working vantage
    if not v6_capable:
        return done("INCONCLUSIVE", "inconclusive", "low", "Scanner has no working IPv6",
                    f"IPv6 {stage.upper()} failed ({ecls}), but this scanner's own IPv6 self-test also failed: "
                    + str(vantage.get("v6", {}).get("detail")),
                    "The failure cannot be attributed to the website when the measuring host itself cannot use IPv6.",
                    "Run V6Scope from a dual-stack host (e.g. EC2 in a dual-stack VPC) to get a verdict.")
    if not v6.get("consistent", True):
        return done("INCONCLUSIVE", "inconclusive", "low", "Inconsistent results on repeat",
                    f"First IPv6 attempt failed at {stage} ({ecls}) but the repeat test behaved differently.",
                    "Transient failures are reported as inconclusive rather than as a definite fault.",
                    "Re-run the scan; investigate packet loss or load-balancer health checks.")

    conf = "high" if hidden else "medium"
    tail = ("" if hidden else " Note: IPv4 also failed, so this is not purely an IPv6 problem.")

    if stage == "tcp":
        addrs = ", ".join(v6_dns.get("addresses", [])[:3])
        cause = {
            "ECONNREFUSED": ("The IPv6 address answered with a TCP reset: nothing is listening on this port over IPv6.",
                             "Web server / load balancer bound only to IPv4 (e.g. listen 0.0.0.0:443 without [::]:443)."),
            "TIMEOUT": ("TCP connection attempts over IPv6 timed out with no reply.",
                        "Packets are being dropped: missing IPv6 firewall/security-group rule, broken IPv6 routing, or a stale AAAA record."),
            "ENETUNREACH": ("No route to the IPv6 address.", "Routing problem or a non-routable/stale AAAA address."),
            "EHOSTUNREACH": ("The IPv6 host is unreachable (ICMPv6 unreachable).", "Routing/firewall problem or stale AAAA address."),
        }.get(ecls, (f"TCP connect over IPv6 failed: {v6.get('error')}", "IPv6 transport problem between scanner and server."))
        return done("FAIL_TCP", comparison, conf, "AAAA exists but TCP over IPv6 fails",
                    cause[0], f"DNS advertises IPv6 address(es) {addrs}, so clients will try them. Likely cause: {cause[1]}" + tail,
                    "Make the service listen on IPv6, open TCP/443 for ::/0 in the firewall/security group, "
                    "or remove the AAAA record until IPv6 is actually served.")
    if stage == "tls":
        a6 = _first_attempt(v6).get("tls") or {}
        c = a6.get("cert") or {}
        presented = ", ".join((c.get("san") or [])[:4]) or c.get("subject_cn") or "unknown"
        a4 = _first_attempt(v4).get("tls") or {}
        c4 = (a4.get("cert") or {})
        diff = ""
        if hidden and c4:
            diff = (f" Over IPv4 the server presents a valid certificate for "
                    f"{', '.join((c4.get('san') or [])[:4]) or c4.get('subject_cn')} — the IPv6 endpoint is configured differently.")
        titles = {"CERT_NAME_MISMATCH": "TLS certificate does not match the hostname over IPv6",
                  "CERT_EXPIRED": "Expired TLS certificate over IPv6",
                  "CERT_UNTRUSTED": "Untrusted TLS certificate chain over IPv6",
                  "CERT_SELF_SIGNED": "Self-signed TLS certificate over IPv6"}
        return done("FAIL_TLS", comparison, conf, titles.get(ecls, "TLS handshake fails over IPv6"),
                    f"{v6.get('error')}. Certificate presented over IPv6 covers: {presented}.",
                    "Browsers will refuse this connection for IPv6 users." + diff
                    + " Likely cause: a separate IPv6 listener / load balancer / CDN edge with a stale or wrong certificate." + tail,
                    "Install the correct certificate on the IPv6 listener (same cert/SNI configuration as IPv4).")
    if stage == "http":
        h6 = _first_attempt(v6).get("http") or {}
        h4 = _first_attempt(v4).get("http") or {}
        if "status" in h6 and h4.get("status") == h6.get("status"):
            return done("IPv6_OK", "parity_ok", "medium", "Same HTTP response on both protocols",
                        f"Both IPv4 and IPv6 returned HTTP {h6['status']}.",
                        "The IPv6 path behaves exactly like IPv4; the resource itself returns an error status.", None)
        return done("FAIL_HTTP", comparison, conf, "HTTP error only over IPv6" if hidden else "HTTP error over IPv6",
                    f"DNS, TCP and TLS succeeded over IPv6, but the server answered {v6.get('error')}"
                    + (f" while IPv4 answered HTTP {h4.get('status')}." if h4.get("status") else "."),
                    "The connection works; the application behind the IPv6 endpoint does not. Likely cause: the IPv6 "
                    "virtual host / backend pool / proxy rule is missing or unhealthy." + tail,
                    "Check the reverse-proxy / load-balancer configuration for the IPv6 listener and its backend health.")
    return done("INCONCLUSIVE", "inconclusive", "low", "Unclassified failure", str(v6.get("error")),
                "Not enough evidence to name a stage.", None)
