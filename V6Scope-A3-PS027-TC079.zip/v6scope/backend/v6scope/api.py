"""FastAPI backend: REST API + serves the dashboard.

Run:  cd backend && uvicorn v6scope.api:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import os
import queue
import threading
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import reports
from .config import ROOT, settings
from .db import DB
from .probe import Prober
from .resolver import FamilyResolver
from .scanner import Scanner
from .vantage import check_vantage

db = DB(settings.db_path)
scanner = Scanner(settings, db)
jobs: "queue.Queue[tuple[str, str]]" = queue.Queue()

app = FastAPI(title="V6Scope API", version="1.0",
              description="IPv6 Website and Dependency Readiness Auditor — AIORI-3 PS-027 (team V6ision)")
app.add_middleware(CORSMiddleware, allow_origins=os.environ.get("V6SCOPE_CORS", "*").split(","),
                   allow_methods=["*"], allow_headers=["*"])


def worker():
    while True:
        sid, url = jobs.get()
        try:
            scanner.run(sid, url)
        except Exception as e:  # already recorded in DB
            print("scan failed:", sid, e)
        finally:
            jobs.task_done()


@app.on_event("startup")
def _start():
    # recover scans interrupted by a restart
    for s in db.list_scans(1000):
        if s["status"] in ("queued", "running"):
            db.update_scan(s["id"], status="error", error="interrupted by server restart")
    threading.Thread(target=worker, daemon=True).start()


class ScanRequest(BaseModel):
    urls: list[str] = Field(..., min_length=1, max_length=50,
                            description="One or more website URLs (max 50 per batch)")
    label: str | None = None


@app.get("/api/health")
def health():
    return {"ok": True, "queue": jobs.qsize()}


@app.get("/api/vantage")
def vantage():
    """Self-test: can this server reach the Internet over IPv4 and over IPv6?"""
    r = FamilyResolver(settings)
    return check_vantage(settings, r, Prober(settings, r))


@app.post("/api/scans", status_code=202)
def create_scans(req: ScanRequest):
    urls = [u for u in (x.strip() for x in req.urls) if u]
    if not urls:
        raise HTTPException(400, "no URLs given")
    try:
        created = scanner.create(urls, req.label)
    except ValueError as e:
        raise HTTPException(400, str(e))
    for s in created["scans"]:
        jobs.put((s["id"], s["url"]))
    return created


@app.get("/api/scans")
def list_scans(limit: int = 200):
    return db.list_scans(limit)


@app.get("/api/scans/{scan_id}")
def get_scan(scan_id: str):
    s = db.get_scan(scan_id)
    if not s:
        raise HTTPException(404, "scan not found")
    return s


@app.delete("/api/scans/{scan_id}")
def delete_scan(scan_id: str):
    db.delete_scan(scan_id)
    return {"deleted": scan_id}


@app.get("/api/scans/{scan_id}/report.json")
def report_json(scan_id: str):
    s = get_scan(scan_id)
    return Response(reports.json_report(s), media_type="application/json",
                    headers={"Content-Disposition": f'attachment; filename="v6scope-{scan_id}.json"'})


@app.get("/api/scans/{scan_id}/report.csv")
def report_csv(scan_id: str):
    s = get_scan(scan_id)
    return PlainTextResponse(reports.csv_report(s), media_type="text/csv",
                             headers={"Content-Disposition": f'attachment; filename="v6scope-{scan_id}.csv"'})


@app.get("/api/scans/{scan_id}/screenshot/{view}")
def screenshot(scan_id: str, view: str):
    if view not in ("v4", "v6"):
        raise HTTPException(400, "view must be v4 or v6")
    p = Path(settings.artifacts_dir) / f"{scan_id}_{view}.png"
    if not p.exists():
        raise HTTPException(404, "no screenshot")
    return FileResponse(p)


FRONT = ROOT / "frontend"
if FRONT.exists():
    app.mount("/", StaticFiles(directory=FRONT, html=True), name="frontend")
