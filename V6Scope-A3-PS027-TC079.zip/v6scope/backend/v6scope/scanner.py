"""Scan orchestration: vantage self-test → discovery → IPv4 + IPv6 probes → diagnosis → store."""
from __future__ import annotations

import ipaddress
import re
import time
import uuid
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit

from .classify import CLASSES, classify
from .config import Settings
from .db import DB
from .discover import discover
from .probe import Prober
from .resolver import FamilyResolver
from .vantage import check_vantage

MULTI_PART_TLDS = {"co.in", "ac.in", "gov.in", "org.in", "net.in", "co.uk", "ac.uk", "com.au", "co.jp", "com.br"}


def site_of(host: str) -> str:
    parts = host.split(".")
    if len(parts) >= 3 and ".".join(parts[-2:]) in MULTI_PART_TLDS:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def new_id() -> str:
    return time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]


def _is_ip(h: str) -> bool:
    try:
        ipaddress.ip_address(h)
        return True
    except ValueError:
        return False


def normalize_url(u: str) -> str:
    u = u.strip()
    if not u:
        return u
    if "://" not in u:
        u = "https://" + u
    sp = urlsplit(u)
    host = sp.hostname or ""
    valid_host = re.fullmatch(r"(?=.{1,253}$)([A-Za-z0-9_](?:[A-Za-z0-9_-]{0,61}[A-Za-z0-9])?\.)*"
                              r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?", host) or _is_ip(host)
    if sp.scheme not in ("http", "https") or not valid_host or " " in u:
        raise ValueError(f"not a valid http(s) URL: {u!r}")
    if not sp.path:
        u += "/"
    return u


def summarize(rows: list[dict], vantage: dict, discovery: dict) -> dict:
    n = len(rows)
    classes = Counter(r["ipv6_class"] for r in rows)
    v4ok = sum(1 for r in rows if r["v4"].get("ok"))
    v6ok = sum(1 for r in rows if r["v6"].get("ok"))
    hidden = [r for r in rows if r["comparison"] == "hidden_v6_failure"]
    hosts = {}
    for r in rows:
        h = hosts.setdefault(r["host"], Counter())
        h[r["ipv6_class"]] += 1
    worst = lambda c: next((k for k in ["FAIL_DNS", "FAIL_TCP", "FAIL_TLS", "FAIL_HTTP", "INCONCLUSIVE", "IPv6_OK"] if c.get(k)), "IPv6_OK")
    host_summary = {h: worst(c) for h, c in hosts.items()}
    tested = n - classes.get("INCONCLUSIVE", 0)
    page = rows[0] if rows else None
    if not n:
        verdict = "NO_DATA"
    elif not vantage.get("v6", {}).get("ok"):
        verdict = "SCANNER_HAS_NO_IPV6"
    elif page and page["ipv6_class"] != "IPv6_OK":
        verdict = "PAGE_NOT_IPV6_READY"
    elif classes.get("IPv6_OK", 0) == n:
        verdict = "IPV6_READY"
    elif hidden:
        verdict = "HIDDEN_IPV6_FAILURES"
    else:
        verdict = "PARTIAL"
    return {
        "resources": n, "hosts": len(hosts), "third_party_hosts": len({r["host"] for r in rows if r["party"] == "third"}),
        "v4_ok": v4ok, "v6_ok": v6ok,
        "v4_rate": round(100 * v4ok / n, 1) if n else 0, "v6_rate": round(100 * v6ok / n, 1) if n else 0,
        "classes": {c: classes.get(c, 0) for c in CLASSES},
        "hidden_v6_failures": len(hidden), "inconclusive": classes.get("INCONCLUSIVE", 0),
        "conclusive": tested, "host_status": host_summary, "verdict": verdict,
        "page_v6": page["ipv6_class"] if page else None,
        "v6_capable_vantage": bool(vantage.get("v6", {}).get("ok")),
        "discovery_method": discovery.get("method"),
    }


class Scanner:
    def __init__(self, settings: Settings, db: DB):
        self.s = settings
        self.db = db

    def create(self, urls: list[str], label: str | None = None) -> dict:
        batch = new_id()
        out = []
        for u in urls:
            u = normalize_url(u)
            if not u:
                continue
            sid = new_id()
            self.db.insert_scan(id=sid, batch_id=batch, url=u, label=label, status="queued",
                                progress="queued", created_at=now())
            out.append({"id": sid, "url": u})
            time.sleep(0.002)
        return {"batch_id": batch, "scans": out}

    def run(self, scan_id: str, url: str, log=print) -> dict:
        db, s = self.db, self.s
        resolver = FamilyResolver(s)
        prober = Prober(s, resolver)

        def progress(msg):
            log(msg)
            db.update_scan(scan_id, progress=msg)

        db.update_scan(scan_id, status="running", started_at=now())
        try:
            progress("Vantage self-test: checking this scanner's own IPv4/IPv6 connectivity")
            vantage = check_vantage(s, resolver, prober, urlsplit(url).hostname or "")
            db.update_scan(scan_id, vantage=vantage)
            progress(f"Vantage: IPv4 {'OK' if vantage['v4']['ok'] else 'NOT available'}, "
                     f"IPv6 {'OK' if vantage['v6']['ok'] else 'NOT available'}. Discovering dependencies…")
            disc = discover(url, s, resolver, scan_id, log=progress)
            db.update_scan(scan_id, discovery={k: v for k, v in disc.items() if k != "resources"})
            res = disc["resources"]
            progress(f"Discovered {len(res)} resources on {len({urlsplit(r['url']).hostname for r in res})} hosts. "
                     f"Probing each over IPv4 and IPv6 separately…")
            main_site = site_of(urlsplit(url).hostname)

            def work(r):
                v4 = prober.probe(r["url"], 4)
                v6 = prober.probe(r["url"], 6)
                return r, v4, v6

            rows = []
            with ThreadPoolExecutor(max_workers=s.workers) as ex:
                for r, v4, v6 in ex.map(work, res):
                    sp = urlsplit(r["url"])
                    diag = classify(r["url"], v4, v6, vantage)
                    rows.append({
                        "scan_id": scan_id, "url": r["url"], "host": sp.hostname, "scheme": sp.scheme,
                        "port": sp.port or (443 if sp.scheme == "https" else 80), "rtype": r.get("type") or "other",
                        "party": "first" if site_of(sp.hostname) == main_site else "third",
                        "referer": r.get("referer"), "seen_in": r.get("seen_in", []), "browser": r.get("browser", {}),
                        "v4": v4, "v6": v6, "ipv6_class": diag["ipv6_class"], "comparison": diag["comparison"],
                        "confidence": diag["confidence"], "diagnosis": diag})
            db.insert_resources(rows)
            summary = summarize(rows, vantage, disc)
            db.update_scan(scan_id, status="done", finished_at=now(), summary=summary,
                           progress=f"Done: {summary['classes']['IPv6_OK']} of {summary['resources']} resources IPv6_OK, "
                                    f"{summary['hidden_v6_failures']} hidden IPv6 failure(s)")
            log(f"Scan {scan_id} done: {summary['verdict']}")
            return summary
        except Exception as e:
            db.update_scan(scan_id, status="error", finished_at=now(), error=f"{type(e).__name__}: {e}")
            raise
