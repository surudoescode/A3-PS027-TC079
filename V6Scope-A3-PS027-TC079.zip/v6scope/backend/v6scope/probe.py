"""Protocol-pinned staged probe: DNS -> TCP -> TLS -> HTTP, for ONE address family.

Nothing here lets the operating system pick the protocol: we open AF_INET sockets for the
IPv4 test and AF_INET6 sockets for the IPv6 test, so Happy Eyeballs (RFC 8305) fallback can
never hide a failure. Each stage is timed and its exact error is kept as evidence.
"""
from __future__ import annotations

import errno
import socket
import ssl
import time
from urllib.parse import urlsplit

from cryptography import x509
from cryptography.x509.oid import NameOID, ExtensionOID

from .config import Settings
from .resolver import FamilyResolver, OK

STAGES = ("dns", "tcp", "tls", "http")


def _ms(t0: float) -> float:
    return round((time.perf_counter() - t0) * 1000, 1)


def _errno_name(e: OSError) -> str:
    if isinstance(e, (socket.timeout, TimeoutError)):
        return "TIMEOUT"
    if e.errno is not None:
        return errno.errorcode.get(e.errno, str(e.errno))
    return type(e).__name__


def make_ssl_context(settings: Settings) -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    try:
        import certifi  # type: ignore
        ctx.load_verify_locations(certifi.where())
    except Exception:
        pass
    if settings.extra_ca:
        ctx.load_verify_locations(settings.extra_ca)
    ctx.set_alpn_protocols(["http/1.1"])
    return ctx


def _cert_summary(der: bytes | None) -> dict | None:
    if not der:
        return None
    try:
        c = x509.load_der_x509_certificate(der)
        cn = [a.value for a in c.subject.get_attributes_for_oid(NameOID.COMMON_NAME)]
        issuer = [a.value for a in c.issuer.get_attributes_for_oid(NameOID.COMMON_NAME)]
        try:
            san = c.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME)
            names = san.value.get_values_for_type(x509.DNSName)
        except x509.ExtensionNotFound:
            names = []
        return {"subject_cn": cn[0] if cn else None, "san": names[:20],
                "issuer_cn": issuer[0] if issuer else None,
                "not_after": c.not_valid_after_utc.isoformat()}
    except Exception as e:
        return {"parse_error": str(e)}


class Prober:
    def __init__(self, settings: Settings, resolver: FamilyResolver):
        self.s = settings
        self.resolver = resolver
        self.ctx = make_ssl_context(settings)
        self.noverify = ssl.create_default_context()
        self.noverify.check_hostname = False
        self.noverify.verify_mode = ssl.CERT_NONE

    # ------------------------------------------------------------------ stages
    def tcp(self, addr: str, port: int, family: int) -> tuple[socket.socket | None, dict]:
        fam = socket.AF_INET if family == 4 else socket.AF_INET6
        t0 = time.perf_counter()
        try:
            s = socket.socket(fam, socket.SOCK_STREAM)
        except OSError as e:
            return None, {"ok": False, "error_class": "NO_LOCAL_STACK", "ms": 0.0,
                          "error": f"cannot create IPv{family} socket on this host: {e}"}
        s.settimeout(self.s.connect_timeout)
        try:
            s.connect((addr, port) if family == 4 else (addr, port, 0, 0))
            local = s.getsockname()[0]
            return s, {"ok": True, "ms": _ms(t0), "local_addr": local}
        except OSError as e:
            s.close()
            name = _errno_name(e)
            return None, {"ok": False, "error_class": name, "ms": _ms(t0),
                          "error": f"{name}: {e.strerror or e}"}

    def tls(self, sock: socket.socket, host: str, addr: str, port: int, family: int):
        t0 = time.perf_counter()
        sock.settimeout(self.s.tls_timeout)
        try:
            ss = self.ctx.wrap_socket(sock, server_hostname=host)
            info = {"ok": True, "ms": _ms(t0), "version": ss.version(),
                    "cipher": (ss.cipher() or [None])[0], "alpn": ss.selected_alpn_protocol(),
                    "cert": _cert_summary(ss.getpeercert(binary_form=True))}
            return ss, info
        except ssl.SSLCertVerificationError as e:
            sock.close()
            info = {"ok": False, "ms": _ms(t0), "error": f"{e.verify_message} ({e.reason})",
                    "error_class": self._cert_error_class(e), "verify_code": e.verify_code}
            # Re-handshake WITHOUT verification only to show which certificate was presented.
            info["cert"] = self._peek_cert(host, addr, port, family)
            return None, info
        except (ssl.SSLError, OSError) as e:
            sock.close()
            name = "HANDSHAKE_" + (_errno_name(e) if not isinstance(e, ssl.SSLError) else (e.reason or "SSL_ERROR"))
            return None, {"ok": False, "ms": _ms(t0), "error_class": name, "error": str(e)[:300]}

    @staticmethod
    def _cert_error_class(e: ssl.SSLCertVerificationError) -> str:
        m = (e.verify_message or "").lower()
        if "hostname mismatch" in m or "ip address mismatch" in m or e.verify_code == 62:
            return "CERT_NAME_MISMATCH"
        if "expired" in m:
            return "CERT_EXPIRED"
        if "self-signed" in m or "self signed" in m:
            return "CERT_SELF_SIGNED"
        if "unable to get local issuer" in m or "unknown ca" in m:
            return "CERT_UNTRUSTED"
        return "CERT_INVALID"

    def _peek_cert(self, host, addr, port, family):
        s, t = self.tcp(addr, port, family)
        if not s:
            return None
        try:
            s.settimeout(self.s.tls_timeout)
            with self.noverify.wrap_socket(s, server_hostname=host) as ss:
                return _cert_summary(ss.getpeercert(binary_form=True))
        except Exception:
            return None

    def http(self, sock, host: str, port: int, path: str, scheme: str) -> dict:
        t0 = time.perf_counter()
        default = 443 if scheme == "https" else 80
        hosthdr = host if port == default else f"{host}:{port}"
        if ":" in host and not host.startswith("["):
            hosthdr = f"[{host}]" if port == default else f"[{host}]:{port}"
        req = (f"GET {path} HTTP/1.1\r\nHost: {hosthdr}\r\nUser-Agent: {self.s.user_agent}\r\n"
               f"Accept: */*\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n").encode()
        sock.settimeout(self.s.http_timeout)
        try:
            sock.sendall(req)
            buf = b""
            while b"\r\n\r\n" not in buf and len(buf) < 65536:
                chunk = sock.recv(8192)
                if not chunk:
                    break
                buf += chunk
            ttfb = _ms(t0)
            head, _, body = buf.partition(b"\r\n\r\n")
            body_len = len(body)
            while body_len < 262144:  # read (bounded) body to confirm content actually flows
                try:
                    chunk = sock.recv(16384)
                except (socket.timeout, TimeoutError):
                    break
                if not chunk:
                    break
                body_len += len(chunk)
            if not head:
                return {"ok": False, "ms": _ms(t0), "error_class": "EMPTY_RESPONSE",
                        "error": "connection closed without an HTTP response"}
            lines = head.decode("iso-8859-1").split("\r\n")
            parts = lines[0].split(" ", 2)
            if len(parts) < 2 or not parts[0].startswith("HTTP/") or not parts[1].isdigit():
                return {"ok": False, "ms": _ms(t0), "error_class": "BAD_RESPONSE",
                        "error": f"not an HTTP response: {lines[0][:80]!r}"}
            status = int(parts[1])
            hdrs = {}
            for ln in lines[1:]:
                k, _, v = ln.partition(":")
                if k.lower() in ("server", "content-type", "content-length", "location",
                                 "alt-svc", "via", "x-served-by", "cf-ray", "x-cache"):
                    hdrs[k.lower()] = v.strip()[:200]
            ok = status < 400
            res = {"ok": ok, "status": status, "reason": parts[2] if len(parts) > 2 else "",
                   "ttfb_ms": ttfb, "ms": _ms(t0), "bytes": body_len, "headers": hdrs}
            if not ok:
                res.update(error_class=f"HTTP_{status}", error=f"HTTP {status} {res['reason']}")
            return res
        except OSError as e:
            name = _errno_name(e)
            return {"ok": False, "ms": _ms(t0), "error_class": "HTTP_" + name, "error": str(e)[:200]}
        finally:
            try:
                sock.close()
            except Exception:
                pass

    # ----------------------------------------------------------------- one try
    def _attempt(self, url: str, family: int) -> dict:
        u = urlsplit(url)
        scheme = u.scheme.lower()
        host = (u.hostname or "").lower()
        port = u.port or (443 if scheme == "https" else 80)
        path = (u.path or "/") + (f"?{u.query}" if u.query else "")
        r = {"family": family, "ok": False, "fail_stage": None, "error_class": None,
             "error": None, "dns": None, "attempts": []}
        d = self.resolver.resolve(host, family)
        r["dns"] = d
        if d["status"] != OK:
            r.update(fail_stage="dns", error_class=d["status"], error=d["error"])
            return r
        last = None
        for addr in d["addresses"][: self.s.max_addrs]:
            a = {"address": addr, "port": port, "tcp": None, "tls": None, "http": None}
            r["attempts"].append(a)
            sock, a["tcp"] = self.tcp(addr, port, family)
            if not sock:
                last = ("tcp", a["tcp"])
                continue
            if scheme == "https":
                sock, a["tls"] = self.tls(sock, host, addr, port, family)
                if not sock:
                    last = ("tls", a["tls"])
                    continue
            a["http"] = self.http(sock, host, port, path, scheme)
            if not a["http"]["ok"]:
                last = ("http", a["http"])
                continue
            r.update(ok=True, address=addr)
            # note if some (but not all) addresses of this family failed
            failed = [x["address"] for x in r["attempts"][:-1]]
            if failed:
                r["partial"] = f"{len(failed)} other IPv{family} address(es) failed: {', '.join(failed)}"
            return r
        stage, info = last
        r.update(fail_stage=stage, error_class=info.get("error_class"), error=info.get("error"))
        return r

    def probe(self, url: str, family: int) -> dict:
        """Run the staged test; repeat failures to check they are consistent."""
        first = self._attempt(url, family)
        if first["ok"] or first["fail_stage"] == "dns":
            first["consistent"] = True
            first["repeats"] = []
            return first
        repeats = []
        for _ in range(self.s.retries):
            time.sleep(0.3)
            rep = self._attempt(url, family)
            repeats.append({"ok": rep["ok"], "fail_stage": rep["fail_stage"],
                            "error_class": rep["error_class"], "error": rep["error"]})
        same = all((x["fail_stage"], x["error_class"]) == (first["fail_stage"], first["error_class"])
                   for x in repeats)
        first["consistent"] = same
        first["repeats"] = repeats
        return first
