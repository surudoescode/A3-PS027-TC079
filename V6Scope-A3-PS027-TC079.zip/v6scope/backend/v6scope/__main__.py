"""Command line: python -m v6scope scan <url> [<url> …]   |   python -m v6scope vantage"""
from __future__ import annotations

import argparse
import json
import sys

from .config import settings
from .db import DB
from .probe import Prober
from .resolver import FamilyResolver
from .scanner import Scanner
from .vantage import check_vantage


def main(argv=None):
    ap = argparse.ArgumentParser(prog="v6scope")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sc = sub.add_parser("scan", help="scan one or more URLs and store results")
    sc.add_argument("urls", nargs="+")
    sc.add_argument("--label")
    sc.add_argument("--json", action="store_true", help="print the stored scan as JSON")
    sub.add_parser("vantage", help="self-test this host's IPv4/IPv6 connectivity")
    a = ap.parse_args(argv)

    if a.cmd == "vantage":
        r = FamilyResolver(settings)
        print(json.dumps(check_vantage(settings, r, Prober(settings, r)), indent=2))
        return 0
    db = DB(settings.db_path)
    scanner = Scanner(settings, db)
    created = scanner.create(a.urls, a.label)
    for s in created["scans"]:
        print(f"\n=== Scan {s['id']}  {s['url']}")
        scanner.run(s["id"], s["url"])
        scan = db.get_scan(s["id"])
        print(f"{'IPv6 class':<13} {'compare':<18} {'type':<11} url")
        for r in scan["resources"]:
            print(f"{r['ipv6_class']:<13} {r['comparison']:<18} {r['rtype']:<11} {r['url']}")
        print("summary:", json.dumps(scan["summary"], indent=None))
        if a.json:
            print(json.dumps(scan, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
