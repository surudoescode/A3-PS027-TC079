"""Vantage-point self test: can THIS machine actually use IPv4 / IPv6 right now?

If the scanner itself has no working IPv6, every IPv6 connection would fail and a naive
tool would blame the website. V6Scope checks first and downgrades such results to
INCONCLUSIVE instead of reporting false failures.
"""
from __future__ import annotations

import socket
import time

from .config import Settings
from .probe import Prober
from .resolver import FamilyResolver, OK


def check_vantage(settings: Settings, resolver: FamilyResolver, prober: Prober, target_host: str = "") -> dict:
    out = {"checked_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "hostname": socket.gethostname(),
           "resolver": resolver.describe()}
    z = settings.lab_zone.lower()
    lab_target = bool(settings.lab_nameserver and z and target_host and
                      (target_host == z or target_host.endswith("." + z)))
    if lab_target:
        # The controlled lab lives on this machine's loopback: the relevant question is whether
        # IPv4/IPv6 work towards the lab's dual-stack control host, not towards the Internet.
        anchors4 = anchors6 = [f"www.{z}:443"]
        out["anchor_scope"] = f"controlled lab ({z})"
    else:
        anchors4, anchors6 = settings.v4_anchors, settings.v6_anchors
        out["anchor_scope"] = "internet"
    for fam, anchors in ((4, anchors4), (6, anchors6)):
        fam_const = socket.AF_INET if fam == 4 else socket.AF_INET6
        info = {"stack": True, "ok": False, "anchors": []}
        try:
            socket.socket(fam_const, socket.SOCK_STREAM).close()
        except OSError as e:
            info.update(stack=False, detail=f"operating system has no IPv{fam} stack ({e.strerror})")
            out[f"v{fam}"] = info
            continue
        for a in anchors:
            host, _, port = a.rpartition(":")
            d = resolver.resolve(host, fam)
            rec = {"anchor": a, "dns": d["status"]}
            if d["status"] == OK:
                for addr in d["addresses"][:2]:
                    s, t = prober.tcp(addr, int(port), fam)
                    rec.update(address=addr, tcp_ok=bool(s), tcp_ms=t.get("ms"),
                               error=t.get("error"))
                    if s:
                        s.close()
                        info["ok"] = True
                        break
            info["anchors"].append(rec)
            if info["ok"]:
                break
        info["detail"] = (f"IPv{fam} connectivity confirmed" if info["ok"] else
                          f"no IPv{fam} anchor reachable from this host")
        out[f"v{fam}"] = info
    return out
