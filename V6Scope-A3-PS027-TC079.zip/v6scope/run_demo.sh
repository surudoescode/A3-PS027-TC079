#!/usr/bin/env bash
# Local demo on any Linux machine with IPv6 enabled (or WSL2 with IPv6):
#   sudo ./run_demo.sh      -> starts V6Lab + dashboard at http://localhost:8000
set -e
cd "$(dirname "$0")"
./lab/setup_net.sh >/dev/null
(cd lab && python3 -u lab.py --dns-port 5300 &) ; sleep 2
mkdir -p data/browser-home/.pki/nssdb
NSS=data/browser-home/.pki/nssdb
[ -f $NSS/cert9.db ] || certutil -d sql:$NSS -N --empty-password
certutil -d sql:$NSS -D -n v6lab 2>/dev/null || true
certutil -d sql:$NSS -A -t "C,," -n v6lab -i lab/certs/ca.pem
export V6SCOPE_LAB_NAMESERVER=127.0.0.1:5300 V6SCOPE_EXTRA_CA=$PWD/lab/certs/ca.pem \
       V6SCOPE_BROWSER_HOME=$PWD/data/browser-home
echo "Dashboard: http://localhost:8000   — scan https://www.v6lab.test/ for the controlled demo"
cd backend && exec python3 -m uvicorn v6scope.api:app --host 0.0.0.0 --port 8000
