# V6Scope — IPv6 Website and Dependency Readiness Auditor

**AIORI-3 Hackathon · Problem statement PS-027 · Submission A3-PS027-TC079 · Team V6ision**
Khushee Kundra · Suravi Nair · Mentor: Dr Vidhya K (PES University)

V6Scope opens a website the way a real visitor would, finds **every server the page depends on**
(stylesheets, scripts, fonts, images, APIs …), and then tests each dependency **separately over IPv4
and over IPv6**, stage by stage — DNS → TCP → TLS → HTTP. It reports which resources fail **only**
over IPv6, at which stage, why, and with what evidence — and it refuses to guess when the evidence is
not good enough.

---

## 1. The problem, in plain words

| Question | Answer |
|---|---|
| **What are we solving?** | A website can "have IPv6" and still be broken for IPv6 users, because a page is not one server — it is a chain of 10–100 resources on many hosts (CDNs, font services, analytics, APIs). If any of them is unreachable over IPv6, IPv6-only users get a page with missing images, no styling, broken login or dead buttons. PS-027 asks for a tool that finds these hidden, per-dependency IPv6 failures. |
| **Why is an AAAA (IPv6 DNS) check not enough?** | An AAAA record only says "an IPv6 address exists". It does not prove that the address accepts connections, that the IPv6 server presents the right TLS certificate, or that the application behind it answers correctly. And it says nothing about the 20 other hosts the page pulls in. |
| **What happens when a site works on IPv4 but some resources fail on IPv6?** | On a dual-stack network the browser quietly falls back to IPv4 (Happy Eyeballs, RFC 8305), so the developer sees a perfect page and never notices. On an IPv6-only network (mobile carriers, new ISPs, IPv6-only cloud) there is nothing to fall back to: the resource simply fails. Some failures (wrong certificate or HTTP error on the IPv6 endpoint) break even dual-stack users, because the TCP connection succeeds and fallback never triggers. |
| **Why is this real?** | Mobile and broadband networks increasingly prefer or require IPv6; cloud providers now charge for public IPv4 (AWS: $0.005/hour per address since 1 Feb 2024), pushing IPv6-only deployments. Yet popular hosting platforms still lack IPv6 entirely — e.g. Vercel's own community forum has an open, unanswered request for IPv6 support. |
| **Limits of existing tools** | DNS checkers look at one name. "Is my site IPv6 ready" testers check the main domain only. Browser add-ons such as IPvFoo show which protocol each resource *happened* to use, but cannot force IPv6-only. SAP's webres6 lists resource addresses but does not run independent per-protocol connection tests with failure-stage diagnosis. |
| **What V6Scope does differently** | (1) discovers dependencies with a **real browser**; (2) shows the page as an **IPv4-only and as an IPv6-only visitor** (side-by-side screenshots); (3) runs **protocol-pinned** probes (AF_INET vs AF_INET6 sockets — no OS fallback possible) through all four stages; (4) **compares** the two and names the failing stage, likely cause and fix, with evidence; (5) **self-tests the scanner** and repeats failures, so it reports `INCONCLUSIVE` instead of false failures; (6) is validated against a **controlled lab website with known faults**. |

## 2. What it does

```
User enters URL(s) ──► Scanner self-test ──► Dependency discovery ──► IPv4 tests ──► IPv6 tests ──► Comparison ──► Diagnosis ──► Dashboard + CSV/JSON
                     (can I use v4/v6?)    (Chromium, v4-only and     (DNS A, TCP,   (DNS AAAA, TCP,  (per resource)  (class, cause,   (history, map,
                                            v6-only views)             TLS, HTTP)     TLS, HTTP)                       fix, evidence)   reports)
```

Result classes: `IPv6_OK`, `FAIL_DNS`, `FAIL_TCP`, `FAIL_TLS`, `FAIL_HTTP`, `INCONCLUSIVE`.
Each resource also gets a comparison label: `hidden_v6_failure` (works on IPv4, fails on IPv6 — the
key PS-027 finding), `parity_ok`, `both_fail`, `v4_only_failure` or `inconclusive`.

## 3. Architecture

```
 Browser (judge / user)
        │ HTTP(S), IPv4 or IPv6
        ▼
 nginx  (listen 80 + [::]:80)                         ← dual-stack EC2 instance (Ubuntu 24.04)
        │
        ▼
 FastAPI backend  v6scope.api ──────────── SQLite (scans, resources, evidence JSON)
   │  background worker queue
   ▼
 Scanner pipeline  v6scope.scanner
   ├─ vantage.py   self-test: can THIS host reach IPv4 / IPv6 anchors?
   ├─ discover.py  Chromium (Playwright) with --host-resolver-rules: IPv4-only view, IPv6-only view
   ├─ resolver.py  separate A / AAAA queries (dnspython); NODATA vs NXDOMAIN vs SERVFAIL
   ├─ probe.py     AF_INET / AF_INET6 sockets: TCP connect → TLS (verify, cert evidence) → raw HTTP/1.1 GET
   ├─ classify.py  compare v4 vs v6 → class, cause, fix, confidence, evidence
   └─ reports.py   CSV / JSON
 V6Lab (lab/)  DNS server for v6lab.test + dual-stack HTTPS servers with deliberate IPv6 faults
```

**Why not run everything on Vercel?** Vercel has no IPv6 (no AAAA for deployments, no IPv6 egress
from functions) — a scanner hosted there would see *every* IPv6 test fail. The measurement engine must
run on a host with real dual-stack connectivity. We deploy the whole app (API + dashboard) on one
**AWS EC2 instance in a dual-stack VPC**; the dashboard is static and could additionally be hosted on
any CDN by setting `window.V6SCOPE_API` in `index.html`.

**Tech choices:** Python FastAPI (async API, auto docs at `/docs`), Playwright/Chromium (real page
loads incl. JS-injected requests), dnspython (exact DNS outcomes), Python `socket`/`ssl` (protocol
pinning, per-stage timing and errors), `cryptography` (certificate evidence), SQLite (zero-ops history),
plain JS + Cytoscape.js dashboard (no build step, vendored so it works offline at the venue).

## 4. Run it locally (Linux / WSL2 / macOS with IPv6)

```bash
cd v6scope
python3 -m venv .venv && . .venv/bin/activate
pip install -r backend/requirements.txt -r lab/requirements.txt
playwright install --with-deps chromium

# dashboard + API
cd backend && uvicorn v6scope.api:app --host 0.0.0.0 --port 8000
# open http://localhost:8000   (API docs: http://localhost:8000/docs)
```

CLI without the dashboard: `cd backend && python -m v6scope scan https://example.com/` and
`python -m v6scope vantage` (is this machine able to test IPv6?).

## 5. The controlled simulation (V6Lab)

`lab/` is a small website, **Mandi Bhav** (crop prices), hosted under the reserved test domain
`v6lab.test` (RFC 6761). Each hostname gets its own loopback IPv4 address and its own IPv6
unique-local address (`fd00:6:1::/64`, RFC 4193). Every resource works over IPv4; the IPv6 side of each
is broken in one deliberate way:

| Case | Resource | Deliberate IPv6 fault | Expected |
|---|---|---|---|
| C0 | `www.v6lab.test/` page | none (dual-stack) | `IPv6_OK` |
| C1 | `ok.v6lab.test/static/app.css` | none — control | `IPv6_OK` |
| C2 | `nov6.v6lab.test/img/logo.svg` | A record, **no AAAA** | `FAIL_DNS` |
| C3 | `deadv6.v6lab.test/js/analytics.js` | AAAA → address with **no listener** on 443 | `FAIL_TCP` |
| C4 | `badcert.v6lab.test/fonts/brand.ttf` (loaded *from the CSS*) | IPv6 listener presents a cert for **legacy-cdn.example.net** | `FAIL_TLS` |
| C5 | `err6.v6lab.test/api/status.json` (loaded *by JavaScript*) | IPv6 virtual host returns **HTTP 503** | `FAIL_HTTP` |
| C6 | `flakydns.v6lab.test/img/partner-badge.svg` | DNS server answers **SERVFAIL** to AAAA | `INCONCLUSIVE` (honesty check) |

Run it (needs root for the loopback addresses and port 443):

```bash
sudo ./lab/setup_net.sh                     # add fd00:6:1::10..15 to lo
sudo .venv/bin/python scripts/run_simulation.py
```

The script starts the lab, scans `https://www.v6lab.test/` through the normal pipeline, compares
every result with the answer key, and writes `docs/simulation/simulation-<time>.json` (also shown in
the dashboard's history). The lab logs every request it receives with the address family it arrived
on (`lab/logs/access.log`) — independent proof of what the scanner actually did.

## 6. Deploy (AWS EC2, dual-stack)

1. VPC → *Edit CIDRs* → add an Amazon-provided IPv6 CIDR. Subnet → add an IPv6 /64, enable
   *auto-assign IPv6*. Route table: `::/0 → Internet Gateway` (and `0.0.0.0/0 → IGW`).
2. Launch Ubuntu 24.04, t3.small (2 GB RAM for Chromium), in that subnet, with an IPv6 address.
   Security group inbound: TCP 80 (and 22) from `0.0.0.0/0` **and** `::/0`.
3. `git clone … && sudo bash v6scope/deploy/setup_ec2.sh` — installs everything, starts `v6lab` and
   `v6scope-api`, configures nginx on IPv4 + IPv6, prints the vantage self-test and public URLs.
4. Check `http://<public-ip>/` shows **Scanner: IPv4 ✓ · IPv6 ✓** in the header.

## 7. API

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/scans` | `{"urls": ["https://…", …]}` → queue a batch (≤ 50) |
| `GET` | `/api/scans` | scan history |
| `GET` | `/api/scans/{id}` | full scan: summary, vantage, discovery, resources + evidence |
| `GET` | `/api/scans/{id}/report.csv` · `/report.json` | downloadable reports |
| `GET` | `/api/scans/{id}/screenshot/{v4\|v6}` | browser view screenshots |
| `DELETE` | `/api/scans/{id}` | remove a scan |
| `GET` | `/api/vantage` | scanner self-test |
| `GET` | `/api/health` | liveness |

## 8. Database schema (SQLite)

`scans(id, batch_id, url, label, status, progress, created_at, started_at, finished_at, vantage JSON, discovery JSON, summary JSON, error)`
`resources(id, scan_id → scans, url, host, port, scheme, rtype, party, referer, seen_in JSON, browser JSON, v4 JSON, v6 JSON, ipv6_class, comparison, confidence, diagnosis JSON)`

## 9. Decision logic (classify.py)

1. IPv6 passed DNS, TCP, TLS and HTTP → `IPv6_OK`.
2. AAAA query = NOERROR/no data while A exists → `FAIL_DNS` (also: IPv4 address literal in the URL).
3. AAAA query SERVFAIL / timeout → `INCONCLUSIVE` (absence not proven; RFC 4074). NXDOMAIN → `INCONCLUSIVE` (not IPv6-specific).
4. Any TCP/TLS/HTTP failure while the **scanner's own IPv6 self-test failed** → `INCONCLUSIVE`.
5. Failure that does **not repeat identically** on retry → `INCONCLUSIVE`.
6. Otherwise the failing stage → `FAIL_TCP` (refused / timeout / unreachable explained), `FAIL_TLS`
   (name mismatch / expired / untrusted, with the certificate actually presented), `FAIL_HTTP`
   (IPv6 status ≥ 400; same error status on both protocols counts as parity, not an IPv6 fault).
7. If IPv4 succeeded → `hidden_v6_failure`, confidence high; if IPv4 failed too → `both_fail`, medium.

## 10. Known limitations (honest list)

* HTTP/3 (QUIC) is disabled in the browser and not probed; we test TCP-based HTTPS.
* The probe tests up to 2 addresses per family per host; large anycast pools are sampled, not exhausted.
* One vantage point per deployment; results describe paths from that host's network.
* Pages behind logins, bot walls or consent pages show only what an anonymous visitor loads.
* NAT64/DNS64 environments are not emulated (planned).

## 11. Team cheat-sheet: explaining it to judges in 60 seconds

"Checking for an AAAA record is like checking that a shop has a phone number — it doesn't tell you
anyone answers. A web page is really 30 shops. V6Scope phones every one of them twice, once on the
IPv4 line and once on the IPv6 line, and writes down exactly where each call failed: no number (DNS),
nobody picks up (TCP), wrong person answers (TLS), or they answer but say 'closed' (HTTP). We proved it
on our own lab website where we broke each step on purpose — and the tool found every fault, and said
'not sure' when it genuinely couldn't know."

## 12. Validation results (real execution, 30 Oct 2026)

Runs on an IPv6-enabled Linux 6.8 kernel (QEMU VM — our cloud build host had IPv6 disabled):

| Case | Resource | Expected | V6Scope | Chromium in the IPv6-only view | |
|---|---|---|---|---|---|
| C0 | `www.v6lab.test/` | `IPv6_OK` | `IPv6_OK` | 200 | ✅ |
| C1 | `ok.v6lab.test/static/app.css` | `IPv6_OK` | `IPv6_OK` | 200 | ✅ |
| C2 | `nov6.v6lab.test/img/logo.svg` | `FAIL_DNS` | `FAIL_DNS` | net::ERR_NAME_NOT_RESOLVED | ✅ |
| C3 | `deadv6.v6lab.test/js/analytics.js` | `FAIL_TCP` | `FAIL_TCP` | net::ERR_CONNECTION_REFUSED | ✅ |
| C4 | `badcert.v6lab.test/fonts/brand.ttf` | `FAIL_TLS` | `FAIL_TLS` | net::ERR_CERT_COMMON_NAME_INVALID | ✅ |
| C5 | `err6.v6lab.test/api/status.json` | `FAIL_HTTP` | `FAIL_HTTP` | 503 | ✅ |
| C6 | `flakydns.v6lab.test/img/partner-badge.svg` | `INCONCLUSIVE` | `INCONCLUSIVE` | net::ERR_NAME_NOT_RESOLVED | ✅ |

* **4/4 independent real-IPv6 runs** matched the answer key 7/7, with identical classifications every time.
* **Scanner without IPv6** (build host): 7/7 against the vantage-aware key — transport cases INCONCLUSIVE, the missing AAAA (C2) still FAIL_DNS, **zero** false failures.
* Evidence files: `docs/simulation/*.json`; screenshots: `docs/img/`; the stored scans are in `data/v6scope.db` (open the dashboard to browse them).
* Updated submission deck: `docs/A3-PS027-TC079-V6Scope-Implementation-Update.pdf`, regenerated from these files by `python3 docs/build_deck.py`.

### Reproduce the real-IPv6 run on a machine whose kernel has IPv6 disabled
`vm/` (not needed on EC2 or a normal laptop) boots a stock Ubuntu kernel in QEMU sharing the host filesystem; see the comments in `scripts/` and `docs/DEMO_SCRIPT.md`.
