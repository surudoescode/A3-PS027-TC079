# V6Scope — live demo runbook (≈ 7 minutes)

## Before judges arrive (on the demo machine — EC2 or a Linux laptop with IPv6 enabled)
1. `sudo systemctl status v6lab v6scope-api` (EC2) **or** `sudo ./run_demo.sh` (laptop).
2. Open the dashboard. The header must show **This server: IPv4 ✓ · IPv6 ✓**. If IPv6 shows ✗, the
   machine has no IPv6: use the backup plan below (and say so — that *is* the honesty feature).
3. Pre-run one scan of `https://www.v6lab.test/` so a finished result is in history (scans take
   ~30–60 s on real hardware; ~3 min in the emulated VM we validated on).

## The story (say this)
> "A website isn't one server, it's a chain of 10–30 resources on different hosts. Checking for an AAAA
> record is like checking a shop has a phone number — not that anyone answers. And browsers hide IPv6
> problems by quietly falling back to IPv4. V6Scope tests every dependency twice — IPv4 and IPv6,
> separately — through four stages: DNS, TCP, TLS, HTTP."

## Live steps
| # | Do | Point out |
|---|----|-----------|
| 1 | Type `https://www.v6lab.test/` → **Start scan** | Pipeline strip: self-test → discovery → IPv4 → IPv6 → compare → diagnose → report |
| 2 | Open the result | Verdict "Hidden IPv6 failures": **4 of 7** resources work on IPv4, fail on IPv6. IPv4 100 % vs IPv6 28.6 % |
| 3 | "What users see" screenshots | Left (IPv4): perfect page. Right (IPv6): logo, script, font, prices API, badge broken. **This is the hidden problem.** |
| 4 | Dependency map | Hosts ◆ with AAAA ✓/✗; double red ring = works on IPv4, fails on IPv6 |
| 5 | Click **FAIL_TLS** row | IPv4 cert `*.v6lab.test` ✓; IPv6 cert `legacy-cdn.example.net` ✗; same failure on repeat; Chromium says `ERR_CERT_COMMON_NAME_INVALID`; cause + fix |
| 6 | Click **INCONCLUSIVE** row | DNS server returned SERVFAIL for AAAA. We do **not** call that "no IPv6" — RFC 4074. Honest answer. |
| 7 | Download **CSV** and **JSON** | Every stage, address, error, certificate and browser observation is in the report |
| 8 | Paste 2–3 real sites (one per line) | Batch scanning + history; real third-party CDNs/fonts discovered automatically |

## How we validated it (one slide / one sentence)
"Our lab website has one deliberately broken IPv6 path per stage. Before scanning we wrote down the
correct answer; V6Scope matched it 7/7 in every repeated run over real IPv6, the browser itself confirmed
every failure, and on a machine *without* IPv6 it reported 'inconclusive' instead of blaming the site."

## Likely judge questions
* **Why not just Happy Eyeballs / a browser extension?** They show what *happened* to work; we force each
  protocol separately so fallback can't hide anything, and we name the failing stage.
* **How do you avoid false positives?** Scanner self-test, repeat-on-failure, SERVFAIL ≠ no-AAAA,
  identical error on both protocols = parity. Uncertain → INCONCLUSIVE.
* **Why EC2 and not Vercel?** Vercel has no IPv6 at all; the scanner would see every IPv6 test fail.
* **Is the simulation real?** Yes — real DNS server, real TLS listeners, real AF_INET6 sockets, real
  Chromium. The lab's access log records which protocol every request arrived on.

## Backup plan (no IPv6 on the venue machine)
Open the stored real-IPv6 scan in history (or `docs/simulation/latest.json`), and show a fresh scan from
the IPv6-less machine to demonstrate the self-test: transport cases → INCONCLUSIVE, missing AAAA → FAIL_DNS.
