#!/usr/bin/env python3
"""Builds the updated submission PDF (16:9 deck) from the ACTUAL result files.

Inputs : docs/simulation/simulation-*.json (written by scripts/run_simulation.py)
         docs/img/*.png (screenshots of the lab browser views and the dashboard)
Output : docs/A3-PS027-TC079-V6Scope-Implementation-Update.pdf
"""
from __future__ import annotations

import base64
import glob
import html
import json
import sys
from collections import Counter
from pathlib import Path

DOCS = Path(__file__).resolve().parent
IMG = DOCS / "img"
OUT = DOCS / "A3-PS027-TC079-V6Scope-Implementation-Update.pdf"
DATE = "30 October 2026"
FOOT = f"V6ision · A3-PS027-TC079 · Implementation update · {DATE}"
PUBLIC_URL = None  # set once the EC2 deployment is live, e.g. "http://<ip>/"

e = lambda s: html.escape(str(s))


def img(name, style=""):
    p = IMG / name
    if not p.exists():
        return f'<div class="missing">[{e(name)} missing]</div>'
    return f'<img src="data:image/png;base64,{base64.b64encode(p.read_bytes()).decode()}" style="{style}">'


# ------------------------------------------------------------------ load evidence
runs = []
for f in sorted(glob.glob(str(DOCS / "simulation" / "simulation-*.json"))):
    d = json.loads(Path(f).read_text())
    d["_file"] = Path(f).name
    runs.append(d)
v6runs = [r for r in runs if r["vantage"]["v6"]]
v4runs = [r for r in runs if not r["vantage"]["v6"]]
if not v6runs:
    sys.exit("no simulation run with IPv6 vantage found")
final = v6runs[-1]
nocap = v4runs[-1] if v4runs else None
cases = final["cases"]
ncase = len(cases)
all_match = sum(r["cases_passed"] == r["cases_total"] for r in v6runs)
sig = lambda r: tuple((c["case"], c["actual"]) for c in r["cases"])
consistent = len({sig(r) for r in v6runs}) == 1
fault_cases = [c for c in cases if c["expected"].startswith("FAIL")]
ok_cases = [c for c in cases if c["expected"] == "IPv6_OK"]
inc_cases = [c for c in cases if c["expected"] == "INCONCLUSIVE"]
detected = sum(c["actual"] == c["expected"] for c in fault_cases)
stage_right = detected
false_alarm = sum(c["actual"] != "IPv6_OK" for c in ok_cases)
inc_right = sum(c["actual"] == "INCONCLUSIVE" for c in inc_cases)
browser_agree = sum(1 for c in cases if c["expected"] != "IPv6_OK" and c["browser_v6"] and
                    (c["browser_v6"].get("error") or (c["browser_v6"].get("status") or 0) >= 400))
elapsed = [r["elapsed_s"] for r in v6runs]
lab_http = [x for x in final["lab_log_counts"] if x["kind"] in ("IPv4", "IPv6")]
if nocap:
    nocap_false = sum(1 for c in nocap["cases"] if c["actual"].startswith("FAIL") and c["actual"] != "FAIL_DNS")
    nocap_match = nocap["cases_passed"]

# ------------------------------------------------------------------ slide helpers
slides: list[str] = []


def slide(section, title, body, sub=""):
    n = len(slides) + 1
    slides.append(f"""<section class="slide"><div class="hdr"><b>AIORI 3</b>&nbsp;&nbsp;&nbsp;{e(section)}</div>
      <h1>{e(title)}</h1>{f'<div class="sub">{sub}</div>' if sub else ''}
      <div class="body">{body}</div>
      <div class="foot"><span>{e(FOOT)}</span><span>{n} / §TOTAL§</span></div></section>""")


def chip(c):
    return f'<span class="chip c-{c}">{c}</span>'


TAG = {"impl": '<span class="tag t-impl">IMPLEMENTED</span>', "test": '<span class="tag t-test">TESTED</span>',
       "plan": '<span class="tag t-plan">PLANNED</span>', "pend": '<span class="tag t-pend">IN PROGRESS</span>'}

# 1 — title
slides.append(f"""<section class="slide title">{img('aiori_logo.png', 'width:92px')}
  <div class="tcode">A3-PS027-TC079</div>
  <div class="ttl">IPv6 Website and Dependency Readiness Auditor</div>
  <div class="tname">V6Scope — implementation &amp; validation update</div>
  <div class="tmeta"><b>Team name: V6ision</b><br>
  <b>Members:</b> Khushee Kundra (kundrakhushee@gmail.com) · Suravi Nair (nair.suravi@gmail.com)<br>
  <b>Mentor:</b> Dr Vidhya K, Associate Professor, Dept. of CSE AIML, PES University (Vidhyak@pes.edu)<br><br>
  <b>AIORI Hackathon 3</b><br><b>Proposal: October 14, 2026 · This update: {DATE}</b></div>
  <div class="foot"><span>{e(FOOT)}</span><span>1 / §TOTAL§</span></div></section>""")

# 2 — problem
slide("Problem Description", "The problem: a page can look fine and still be broken over IPv6", f"""
<div class="cols2">
<div>
<p class="lead">A web page is not one server. It is a chain of resources — stylesheets, scripts, fonts, images, APIs — often on 10–30 different hosts. <b>Every one of them</b> must work over IPv6 for an IPv6-only visitor to get a working page.</p>
<ul class="pts">
<li><b>Checking the address isn't enough.</b> An AAAA record only says an IPv6 address <i>exists</i>. It does not prove the server accepts connections, presents the right certificate, or answers correctly.</li>
<li><b>Fallback hides failures.</b> On dual-stack networks browsers quietly fall back to IPv4 (Happy Eyeballs, RFC 8305), so developers see a perfect page.</li>
<li><b>Real users are affected.</b> On IPv6-only networks there is nothing to fall back to: missing images, no styling, broken login or dead buttons.</li>
<li><b>Pressure is growing.</b> AWS has charged for every public IPv4 address since 1 Feb 2024 [13]; popular platforms (e.g. Vercel) still offer no IPv6 at all [14].</li>
</ul></div>
<div class="callout">
<div class="ctitle">What PS-027 asks — and what V6Scope answers</div>
<table class="t small"><tr><th>Question</th><th>V6Scope's answer</th></tr>
<tr><td>Which dependencies does the page really load?</td><td>Real Chromium discovers them, incl. CSS- and JS-initiated requests</td></tr>
<tr><td>Which of them fail <i>only</i> over IPv6?</td><td>Each one is tested over IPv4 and IPv6 separately, then compared</td></tr>
<tr><td>Where exactly does it fail?</td><td>DNS → TCP → TLS → HTTP, with the failing stage and its error</td></tr>
<tr><td>Why, and what to fix?</td><td>Likely cause, evidence and a suggested fix per resource</td></tr>
<tr><td>Can the result be trusted?</td><td>Scanner self-test + repeat tests; uncertain cases are <b>INCONCLUSIVE</b>, never guessed</td></tr>
</table></div></div>""")

# 3 — background (retained)
slide("Background", "Six simple ideas behind this project", """
<div class="six">
<div><h3>IPv4 and IPv6</h3>Different protocols. Successful access over IPv4 does not establish that the same service is reachable over IPv6.</div>
<div><h3>DNS: an address is not a guarantee</h3>A records hold IPv4 addresses, AAAA records IPv6 addresses (RFC 3596). They describe addresses, not whether a connection will succeed.</div>
<div><h3>A webpage is a dependency chain</h3>Scripts, stylesheets, fonts, images and API calls may each depend on a different host with its own configuration.</div>
<div><h3>Every request has four failure points</h3>DNS resolution, TCP connection, TLS negotiation and the HTTP exchange. Knowing <i>where</i> it fails points to the cause.</div>
<div><h3>The fallback effect</h3>With both protocols available, browsers may load the page over IPv4 despite IPv6 problems. A successful page load is not proof of IPv6 readiness.</div>
<div><h3>Evidence-based testing</h3>Reliable assessment needs protocol-specific tests of the actual resources, compared side by side — and honesty when evidence is missing.</div>
</div>""")

# 4 — literature
slide("Literature & RFC Review", "What already exists, what was missing, and what we built", """
<table class="t"><tr><th style="width:20%">Existing work</th><th style="width:38%">What it does</th><th>What is missing for PS-027</th></tr>
<tr><td>SAP webres6 [2]</td><td>Opens pages in a real browser, lists IPv4/IPv6 addresses of contacted servers, reports.</td><td>No independent IPv4-only vs IPv6-only connection tests with failure-stage diagnosis.</td></tr>
<tr><td>IPvFoo [10]</td><td>Shows whether each resource was fetched over IPv4 or IPv6.</td><td>Shows what <i>happened</i> to be used; cannot force IPv6-only or explain failures.</td></tr>
<tr><td>RFC 8200, RFC 3596 [3,4]</td><td>IPv6, and AAAA records in DNS.</td><td>An AAAA record does not prove reachability.</td></tr>
<tr><td>RFC 8305 Happy Eyeballs v2 [5]</td><td>Clients race IPv6 and IPv4 to improve success.</td><td>The same fallback hides IPv6 failures from testers.</td></tr>
<tr><td>RFC 9293, 8446, 9110 [6–8]</td><td>TCP, TLS 1.3 and HTTP semantics.</td><td>Define the four stages V6Scope tests and reports.</td></tr>
<tr><td>RFC 4074 [15]</td><td>Documents DNS servers that mishandle AAAA queries.</td><td>Basis for our rule: a broken AAAA answer ≠ "no IPv6" → INCONCLUSIVE.</td></tr>
</table>
<div class="callout" style="margin-top:14px"><b>What V6Scope adds (now implemented):</b> real-browser discovery viewed as an IPv4-only <i>and</i> an IPv6-only visitor; protocol-pinned DNS/TCP/TLS/HTTP probes; per-resource comparison with failing stage, cause, fix and evidence; scanner self-test; validation against a controlled website with a known answer key.</div>""")

# 5 — solution
slide("Proposed Solution", "V6Scope: what it does, end to end", f"""
<div class="flow">
<div><b>1 · Submit</b><span>One or many URLs (≤ 50 per batch) from the dashboard, API or CLI</span></div>
<div><b>2 · Self-test</b><span>Can <i>this scanner</i> reach IPv4 and IPv6 anchors? If not, IPv6 transport results become INCONCLUSIVE</span></div>
<div><b>3 · Discover</b><span>Chromium loads the page twice: hosts pinned to IPv4 addresses, then to IPv6 addresses; screenshots of both</span></div>
<div><b>4 · Probe</b><span>Every resource, separately over IPv4 and IPv6: DNS (A / AAAA) → TCP → TLS → HTTP, timed, errors kept; failures repeated</span></div>
<div><b>5 · Diagnose</b><span>Compare v4 vs v6 → class, failing stage, likely cause, fix, confidence, evidence</span></div>
<div><b>6 · Report</b><span>Dashboard, dependency map, scan history, CSV and JSON downloads</span></div>
</div>
<div class="cols2" style="margin-top:16px">
<div><h3>Result classes (PS-027)</h3>
<table class="t small"><tr><td>{chip('IPv6_OK')}</td><td>All four stages succeed over IPv6</td></tr>
<tr><td>{chip('FAIL_DNS')}</td><td>No AAAA record (or a hard-coded IPv4 literal)</td></tr>
<tr><td>{chip('FAIL_TCP')}</td><td>AAAA exists but TCP connect is refused / times out / unreachable</td></tr>
<tr><td>{chip('FAIL_TLS')}</td><td>Certificate mismatch, expired, untrusted, or handshake error</td></tr>
<tr><td>{chip('FAIL_HTTP')}</td><td>Connection works, but IPv6 gets an HTTP error that IPv4 does not</td></tr>
<tr><td>{chip('INCONCLUSIVE')}</td><td>Evidence insufficient — reported honestly, not guessed</td></tr></table></div>
<div><h3>The key finding: a <span style="color:#c62828">hidden</span> IPv6 failure</h3>
<p>A resource that <b>works over IPv4 but fails over IPv6</b> is flagged <span class="hid">v4 ✓ v6 ✗</span>. This is exactly what developers on IPv4 or dual-stack networks never see — and what V6Scope makes visible, per resource, with the stage that failed.</p>
<p class="small muted">{TAG['impl']} {TAG['test']} all six steps run in the delivered code and were exercised in the simulation.</p></div></div>""")

# 6 — technologies
slide("Technology Stack", "Technologies actually used — and why", f"""
<table class="t"><tr><th style="width:17%">Layer</th><th style="width:25%">Choice</th><th>Why (and what we rejected)</th></tr>
<tr><td>Measurement engine</td><td>Python 3 <code>socket</code> + <code>ssl</code></td><td>AF_INET vs AF_INET6 sockets pin the protocol — the OS cannot fall back. Raw HTTP/1.1 GET gives exact status and timing per stage.</td></tr>
<tr><td>DNS</td><td>dnspython</td><td>Separate A and AAAA queries; distinguishes NODATA, NXDOMAIN, SERVFAIL, timeout (getaddrinfo cannot). CNAME chain kept as evidence.</td></tr>
<tr><td>Certificates</td><td>cryptography</td><td>Records the certificate actually presented (SANs, issuer, expiry) even when verification fails.</td></tr>
<tr><td>Discovery</td><td>Playwright + Chromium</td><td>Real page loads find CSS-, JS- and font-initiated requests that HTML parsing misses. <code>--host-resolver-rules</code> pins each host to its IPv4 or IPv6 address. Static parser kept as fallback.</td></tr>
<tr><td>Backend API</td><td>FastAPI + background worker</td><td>Small, typed, auto-documented (<code>/docs</code>); scans run asynchronously with progress.</td></tr>
<tr><td>Storage</td><td>SQLite</td><td>Zero-ops scan history; full evidence stored as JSON. (PostgreSQL not needed at hackathon scale.)</td></tr>
<tr><td>Dashboard</td><td>HTML/JS + Cytoscape.js</td><td>No build step, vendored locally so the demo works offline. (Chosen over React Flow to avoid a build pipeline.)</td></tr>
<tr><td>Controlled lab</td><td>dnslib + asyncio TLS servers</td><td>Own authoritative DNS and per-address HTTPS listeners → every fault is deterministic.</td></tr>
<tr><td>Hosting</td><td>AWS EC2, dual-stack VPC</td><td><b>Not Vercel:</b> no IPv6 for deployments or function egress [14]; a scanner there would see every IPv6 test fail.</td></tr>
</table>""")

# 7 — architecture
slide("Architecture Design", "System architecture (as implemented)", """
<div class="arch archz">
 <div class="box user" style="left:0;top:20px;width:150px">User / judge<br><small>browser, IPv4 or IPv6</small></div>
 <div class="box" style="left:195px;top:20px;width:170px"><b>nginx</b><br><small>listen 80 and [::]:80</small></div>
 <div class="box main" style="left:410px;top:0px;width:230px;height:100px"><b>FastAPI backend</b><br><small>REST API · serves dashboard · job queue + worker</small></div>
 <div class="box db" style="left:700px;top:10px;width:180px"><b>SQLite</b><br><small>scans · resources · evidence JSON · screenshots</small></div>
 <div class="arrow" style="left:152px;top:42px;width:40px"></div><div class="arrow" style="left:367px;top:42px;width:40px"></div>
 <div class="arrow" style="left:642px;top:42px;width:55px"></div>
 <div class="grp" style="left:150px;top:135px;width:800px;height:250px"><div class="glabel">Scanner pipeline (v6scope.scanner)</div>
  <div class="box" style="left:18px;top:38px;width:170px"><b>vantage.py</b><br><small>scanner self-test: IPv4 / IPv6 anchors</small></div>
  <div class="box" style="left:208px;top:38px;width:180px"><b>discover.py</b><br><small>Chromium · IPv4-only view · IPv6-only view</small></div>
  <div class="box v4" style="left:408px;top:30px;width:170px"><b>probe.py — IPv4</b><br><small>A → AF_INET TCP → TLS → HTTP</small></div>
  <div class="box v6" style="left:408px;top:120px;width:170px"><b>probe.py — IPv6</b><br><small>AAAA → AF_INET6 TCP → TLS → HTTP</small></div>
  <div class="box" style="left:600px;top:70px;width:180px"><b>classify.py</b><br><small>compare · class · stage · cause · fix · confidence</small></div>
  <div class="box" style="left:18px;top:160px;width:370px"><b>resolver.py</b> <small>— separate A / AAAA queries; split DNS: <i>v6lab.test</i> → lab DNS, rest → system resolver</small></div>
 </div>
 <div class="box lab" style="left:0;top:405px;width:430px"><b>V6Lab</b> — controlled website <small>(lab DNS 127.0.0.1:5300 + dual-stack HTTPS listeners on loopback with deliberate IPv6 faults)</small></div>
 <div class="box inet" style="left:470px;top:405px;width:480px"><b>Internet targets</b> <small>— any public website and all its third-party hosts (CDNs, fonts, analytics, APIs)</small></div>
</div>
<p class="small muted" style="margin-top:6px">Both targets are tested by the same pipeline; the only lab-specific setting is which DNS server answers for <i>v6lab.test</i>.</p>""")

# 8 — DFD
slide("Data Flow Diagram", "Data flow (as implemented)", """
<div class="dfd">
 <div class="ext">User</div><div class="ar">→ URL list</div>
 <div class="proc">1. Validate URLs<br><small>normalise, create scan + batch IDs</small></div><div class="ar">→</div>
 <div class="proc">2. Scanner self-test<br><small>IPv4 / IPv6 anchors</small></div><div class="ar">→</div>
 <div class="proc">3. Discover<br><small>IPv4-only view + IPv6-only view (Chromium)</small></div>
</div>
<div class="dfd" style="margin-top:14px">
 <div class="proc">4a. Probe over IPv4<br><small>A · TCP · TLS · HTTP</small></div><div class="ar">+</div>
 <div class="proc">4b. Probe over IPv6<br><small>AAAA · TCP · TLS · HTTP · repeat on failure</small></div><div class="ar">→</div>
 <div class="proc">5. Compare &amp; diagnose<br><small>class, stage, cause, fix, confidence</small></div><div class="ar">→</div>
 <div class="store">D1 SQLite<br><small>scans · resources · evidence</small></div>
</div>
<div class="dfd" style="margin-top:14px">
 <div class="store">D2 Screenshots<br><small>IPv4 / IPv6 views</small></div><div class="ar">→</div>
 <div class="proc">6. Dashboard<br><small>summary, map, history, evidence drawer</small></div><div class="ar">+</div>
 <div class="proc">7. Reports<br><small>CSV · JSON (full evidence)</small></div><div class="ar">→</div>
 <div class="ext">User / evaluator</div>
</div>
<p class="small muted" style="margin-top:16px">Rounded boxes = processes · square boxes = external users · D1/D2 = data stores. Discovery (3) feeds the resource list for 4a/4b; the browser's own observations are stored alongside the probe results as independent corroboration.</p>""")

# 9 — decision logic
slide("Diagnostic Engine", "How V6Scope decides — and how it avoids false conclusions", f"""
<div class="cols2">
<div><h3>Decision rules (classify.py)</h3>
<ol class="pts small">
<li>All IPv6 stages pass → {chip('IPv6_OK')}</li>
<li>AAAA = NOERROR with no data, A exists → {chip('FAIL_DNS')}</li>
<li>TCP refused / timeout / unreachable → {chip('FAIL_TCP')} (cause named per error)</li>
<li>Certificate or handshake failure → {chip('FAIL_TLS')} + certificate actually presented</li>
<li>IPv6 HTTP status ≥ 400 where IPv4 succeeds → {chip('FAIL_HTTP')}; the <i>same</i> error on both = parity, not an IPv6 fault</li>
<li>IPv4 succeeded → <span class="hid">hidden</span>, confidence high; IPv4 failed too → "both fail", confidence medium</li>
</ol></div>
<div><h3>Guard-rails → {chip('INCONCLUSIVE')}</h3>
<table class="t small">
<tr><td><b>Scanner has no IPv6</b></td><td>Self-test failed → transport failures are not blamed on the site</td></tr>
<tr><td><b>Not repeatable</b></td><td>Failure is re-tested; if the repeat differs → inconclusive</td></tr>
<tr><td><b>AAAA SERVFAIL / timeout</b></td><td>Absence of IPv6 not proven (RFC 4074)</td></tr>
<tr><td><b>NXDOMAIN</b></td><td>Name missing on both protocols — not IPv6-specific</td></tr></table>
<h3 style="margin-top:12px">Evidence kept for every resource</h3>
<p class="small">DNS answers, CNAMEs and timings · each address tried · TCP errno · TLS version, cipher, certificate SANs/issuer · HTTP status, bytes, server header · repeat outcomes · what Chromium itself saw in each view.</p>
<p class="small muted">{TAG['impl']} {TAG["test"]} 8 offline unit tests cover these rules (<code>backend/tests</code>).</p></div></div>""")

# 10 — simulation methodology
rows = "".join(f"<tr><td>{c['case']}</td><td>{e(c['name'].replace(' (HTML document)','').replace('Honesty check: ',''))}</td><td class='mono'>{e(c['url'].replace('https://',''))}</td><td>{e(c['fault'])}</td><td>{chip(c['expected'])}</td></tr>" for c in cases)
slide("Simulation Methodology", "The controlled website (“answer key”): V6Lab", f"""
<div class="cols2" style="grid-template-columns:1.9fr 1fr;gap:20px">
<div><table class="t tiny"><tr><th>Case</th><th>Scenario</th><th>Resource</th><th>Deliberate IPv6 fault</th><th>Expected</th></tr>{rows}</table>
<p class="small muted">Every resource works over IPv4. C4 is loaded <i>by the stylesheet</i>, C5 <i>by JavaScript</i> — discoverable only with a real browser.</p></div>
<div class="callout tiny"><div class="ctitle">How the faults are built</div>
<ul class="pts">
<li>Domain <b>v6lab.test</b> — the .test TLD is reserved for testing (RFC 6761 [16]).</li>
<li>Own DNS server: A/AAAA per host; C2 answers NOERROR with no AAAA; C6 answers SERVFAIL.</li>
<li>Each host: own IPv4 loopback address + own IPv6 unique-local address <b>fd00:6:1::/64</b> (RFC 4193 [17]).</li>
<li>C3: address configured but <b>no listener</b> → TCP RST. C4: IPv6 listener uses a cert for <i>legacy-cdn.example.net</i>. C5: IPv6 vhost returns 503.</li>
<li>The lab logs every request with the address family it arrived on — independent evidence.</li>
</ul>
<div class="ctitle" style="margin-top:8px">Where the IPv6 test ran</div>
Our build server's kernel had IPv6 disabled (a real hosting limitation). The simulation therefore ran inside a QEMU virtual machine with its own Linux 6.8 kernel and a <b>genuine IPv6 stack</b>; same code, real AF_INET6 sockets, real Chromium.</div></div>""")

# 11 — results
res = "".join(f"<tr><td>{c['case']}</td><td class='mono'>{e(c['url'].replace('https://','').split('/')[0])}</td><td>{chip(c['expected'])}</td><td>{chip(c['actual'])}</td><td>{'✓' if c['v4_ok'] else '✗'}</td><td class='small'>{e((c['v6_error'] or '—')[:70])}</td><td class='small mono'>{e((c['browser_v6'] or {}).get('error') or (c['browser_v6'] or {}).get('status') or '—')}</td><td class='{'okt' if c['match'] else 'badt'}'>{'MATCH' if c['match'] else 'MISS'}</td></tr>" for c in cases)
slide("Simulation Results", f"Expected vs actual: {final['cases_passed']}/{final['cases_total']} cases correct over real IPv6", f"""
<table class="t small"><tr><th>Case</th><th>Host</th><th>Expected</th><th>V6Scope result</th><th>IPv4</th><th>IPv6 error recorded by the probe</th><th>Chromium (IPv6 view)</th><th></th></tr>{res}</table>
<div class="cols3" style="margin-top:12px">
<div class="kpi"><div class="v">{final['cases_passed']}/{final['cases_total']}</div><div class="l">cases match the answer key (scan {e(final['scan_id'])})</div></div>
<div class="kpi"><div class="v">{browser_agree}/{ncase - len(ok_cases)}</div><div class="l">non-OK cases independently confirmed by Chromium's own error in the IPv6 view</div></div>
<div class="kpi"><div class="v">{final['summary']['hidden_v6_failures']}</div><div class="l">hidden failures: resources that work over IPv4 but fail over IPv6</div></div>
</div>
<p class="small muted">Source: <code>docs/simulation/{e(final['_file'])}</code> — written by <code>scripts/run_simulation.py</code> from the stored scan; nothing hand-entered.</p>""")

# 12 — the demo screenshots
slide("Simulation Screenshots", "The key demonstration: same page, IPv4-only vs IPv6-only visitor", f"""
<div class="cols2">
<figure>{img('lab_v4.png', 'width:100%')}<figcaption><b>IPv4-only view</b> — everything loads. This is what a developer on an IPv4 (or dual-stack) network sees.</figcaption></figure>
<figure>{img('lab_v6.png', 'width:100%')}<figcaption><b>IPv6-only view</b> — logo, analytics script, brand font, prices API and partner badge fail; prices show "HTTP 503".</figcaption></figure>
</div>
<p class="small muted">Both screenshots were taken automatically by V6Scope during the scan (real Chromium in the IPv6-enabled VM, each hostname pinned to its IPv4 or IPv6 address). The status column is written by the page's own JavaScript from what actually loaded.</p>""")

# 13 — dashboard
slide("Dashboard", "Dashboard: verdict, success rates, failure categories, what users see", f"""
{img('dash_top.png', 'width:100%;height:455px;object-fit:cover;object-position:top;border:1px solid #ddd;border-radius:6px')}
<p class="small muted">Live dashboard (FastAPI + plain JS) showing the real-IPv6 simulation scan: pipeline status, verdict, IPv4 100% vs IPv6 success rate, hidden-failure count, failure categories, scanner vantage self-test and the two browser views. CSV / JSON report buttons at the top right. <b>Note:</b> the red header badge describes the machine <i>displaying</i> the dashboard (our IPv6-less build server); the scan itself ran in the IPv6-enabled VM, as the "Scanner vantage point" panel records.</p>""")

# 14 — map + drawer
slide("Dependency Map & Evidence", "Dependency map and per-resource evidence", f"""
<div class="cols2" style="grid-template-columns:1fr 1.1fr">
<figure>{img('dash_map.png', 'width:100%;max-height:420px;object-fit:contain;border:1px solid #ddd;border-radius:6px')}<figcaption>Page → hosts (◆, "AAAA ✓/✗") → resources (●), coloured by class; double red ring = works on IPv4, fails on IPv6.</figcaption></figure>
<figure>{img('dash_drawer.png', 'width:100%;height:470px;object-fit:cover;object-position:top;border:1px solid #ddd;border-radius:6px')}<figcaption>Click any resource: stage-by-stage IPv4 vs IPv6, the wrong certificate actually presented, repeat result, browser's own error, likely cause and fix.</figcaption></figure>
</div>""")

# 15 — evaluation
cons_txt = "identical classification in every run" if consistent else "results differed between runs"
nocap_html = ""
if nocap:
    nocap_html = f"""<tr><td>Scanner <b>without</b> IPv6 (cloud build server, IPv6 disabled)</td><td>{nocap_match}/{nocap['cases_total']} match the vantage-aware answer key; <b>{nocap_false}</b> false TCP/TLS/HTTP failures — transport cases reported INCONCLUSIVE, C2 (missing AAAA) still reported as FAIL_DNS</td><td>{TAG['test']}</td></tr>"""
slide("Evaluation", "Evaluation metrics and validation results", f"""
<table class="t"><tr><th style="width:30%">Metric (from proposal)</th><th>Result</th><th style="width:12%">Status</th></tr>
<tr><td>Detect all known failures</td><td><b>{detected}/{len(fault_cases)}</b> injected IPv6 faults detected (C2–C5)</td><td>{TAG['test']}</td></tr>
<tr><td>Identify the failing stage</td><td><b>{stage_right}/{len(fault_cases)}</b> with the correct stage: DNS, TCP, TLS, HTTP</td><td>{TAG['test']}</td></tr>
<tr><td>No false alarms on working resources</td><td><b>{false_alarm}</b> false alarms on {len(ok_cases)} working resources (C0, C1)</td><td>{TAG['test']}</td></tr>
<tr><td>Report uncertainty honestly</td><td>{inc_right}/{len(inc_cases)} ambiguous case (C6, AAAA SERVFAIL) reported INCONCLUSIVE, not FAIL_DNS</td><td>{TAG['test']}</td></tr>
<tr><td>Consistency across repeated scans</td><td><b>{all_match}/{len(v6runs)}</b> independent real-IPv6 runs fully correct; {cons_txt}</td><td>{TAG['test']}</td></tr>
{nocap_html}
<tr><td>Independent corroboration</td><td>Chromium's own errors agree with the probe for {browser_agree}/{ncase - len(ok_cases)} non-OK cases; lab access log confirms IPv6 requests arrived on the expected listeners</td><td>{TAG['test']}</td></tr>
<tr><td>Scan time (7 resources, emulated VM)</td><td>{min(elapsed):.0f}–{max(elapsed):.0f} s per scan under CPU emulation (QEMU/TCG, no KVM); dominated by 6 browser launches</td><td>{TAG['test']}</td></tr>
<tr><td>30 real-world websites</td><td>Supported by batch scanning; measurement campaign to run on the dual-stack EC2 deployment</td><td>{TAG['pend']}</td></tr>
</table>""")

# 16 — deployment
url_html = (f'<b>Public URL:</b> <span class="mono">{e(PUBLIC_URL)}</span>' if PUBLIC_URL else
            '<b>Public URL:</b> <i>to be added once the EC2 instance is launched on the team\'s AWS account</i> — not yet live at the time of this update.')
slide("Cloud Deployment", "Cloud deployment architecture", f"""
<div class="cols2" style="grid-template-columns:1.15fr 1fr">
<div class="arch" style="height:330px">
 <div class="grp" style="left:0;top:0;width:560px;height:300px"><div class="glabel">AWS VPC — dual-stack (IPv4 CIDR + Amazon-provided IPv6 /56)</div>
  <div class="box" style="left:20px;top:40px;width:200px"><b>Internet Gateway</b><br><small>routes 0.0.0.0/0 and ::/0</small></div>
  <div class="grp" style="left:240px;top:30px;width:300px;height:250px"><div class="glabel">Public subnet (IPv4 + IPv6 /64)</div>
   <div class="box main" style="left:15px;top:36px;width:268px"><b>EC2 t3.small · Ubuntu 24.04</b><br><small>public IPv4 + global IPv6</small></div>
   <div class="box" style="left:15px;top:112px;width:128px"><small><b>nginx</b><br>:80 + [::]:80</small></div>
   <div class="box" style="left:155px;top:112px;width:128px"><small><b>v6scope-api</b><br>uvicorn · Chromium</small></div>
   <div class="box lab" style="left:15px;top:178px;width:268px"><small><b>v6lab</b> (systemd) · loopback-only lab DNS + HTTPS</small></div>
  </div>
  <div class="box" style="left:20px;top:150px;width:200px"><b>Security group</b><br><small>in: TCP 80/22 from 0.0.0.0/0 and ::/0 · out: all</small></div>
 </div></div>
<div class="small"><h3>Why EC2, not Vercel</h3>
<p>The measurement engine needs <b>genuine outbound IPv6</b>. Vercel offers no IPv6 for deployments or functions (open community request, no ETA [14]). An EC2 instance in a dual-stack subnet has both, and the dashboard itself is served over IPv4 and IPv6.</p>
<h3>One-command install</h3><p><code>sudo bash deploy/setup_ec2.sh</code> installs Python deps, Chromium, lab certificates, two systemd services and nginx, then prints the scanner self-test.</p>
<h3>Status</h3><p>{TAG['impl']} deployment script and service files · {TAG['pend']} launch on AWS and public URL.</p>
<p>{url_html}</p></div></div>""")

# 17 — timeline & status
slide("Deployment Timeline", "Development timeline and implementation status", f"""
<table class="t small"><tr><th>Milestone</th><th>Dates (2026)</th><th>Work</th><th>Status</th></tr>
<tr><td>Level 1: proposal &amp; setup</td><td>by 14 Oct</td><td>Problem analysis, proposal, repo, team video</td><td>{TAG['test']} done</td></tr>
<tr><td>M1: Lab &amp; controlled site</td><td>15–21 Oct</td><td>V6Lab: DNS + dual-stack HTTPS, 7 cases incl. honesty check</td><td>{TAG['impl']} {TAG['test']}</td></tr>
<tr><td>M2: Measurement engine</td><td>18–27 Oct</td><td>Per-family DNS/TCP/TLS/HTTP probes, browser discovery (v4 / v6 views), decision logic, self-test</td><td>{TAG['impl']} {TAG['test']}</td></tr>
<tr><td>M3: Dashboard &amp; reports</td><td>24–31 Oct</td><td>Dashboard, dependency map, history, evidence drawer, CSV/JSON</td><td>{TAG['impl']} {TAG['test']}</td></tr>
<tr><td>M4: Evaluation</td><td>28 Oct–3 Nov</td><td>Answer-key validation ({all_match}/{len(v6runs)} runs), no-IPv6 vantage run · 30-website campaign</td><td>{TAG['test']} {TAG['pend']}</td></tr>
<tr><td>M5: Demo &amp; refinement</td><td>31 Oct–4 Nov</td><td>EC2 deployment + public URL, live demo, mentor feedback</td><td>{TAG['pend']}</td></tr>
</table>
<div class="cols3" style="margin-top:12px">
<div class="callout small"><div class="ctitle">Implemented &amp; tested</div>URL/batch scanning · browser discovery with IPv4-only and IPv6-only views · per-family staged probes · six-class diagnosis with guard-rails · dashboard, map, history · CSV/JSON · lab with 7 cases</div>
<div class="callout small"><div class="ctitle">Implemented, not yet run in production</div>EC2 install script, systemd services, dual-stack nginx · internet-site scanning from a dual-stack vantage point (code path shared with the lab)</div>
<div class="callout small"><div class="ctitle">Planned</div>Public URL · 30-website measurement campaign · NAT64/DNS64 emulation · HTTP/3 (QUIC) probing · multiple vantage points</div>
</div>""")

# 18 — bibliography
slide("Bibliography", "Bibliography", """<ol class="bib">
<li>AIORI-3 Hackathon. "PS-027: IPv6 Website and Dependency Readiness Auditor." Problem statement, Internet Measurement category, 2026.</li>
<li>SAP SE. "webres6: IPv6 Web Resource Checker." https://github.com/SAP/webres6 (accessed Oct. 14, 2026).</li>
<li>S. Deering, R. Hinden. "Internet Protocol, Version 6 (IPv6) Specification." RFC 8200, IETF, July 2017.</li>
<li>S. Thomson et al. "DNS Extensions to Support IP Version 6." RFC 3596, IETF, Oct. 2003.</li>
<li>D. Schinazi, T. Pauly. "Happy Eyeballs Version 2: Better Connectivity Using Concurrency." RFC 8305, IETF, Dec. 2017.</li>
<li>W. Eddy (Ed.). "Transmission Control Protocol (TCP)." RFC 9293, IETF, Aug. 2022.</li>
<li>E. Rescorla. "The Transport Layer Security (TLS) Protocol Version 1.3." RFC 8446, IETF, Aug. 2018.</li>
<li>R. Fielding, M. Nottingham, J. Reschke (Eds.). "HTTP Semantics." RFC 9110, IETF, June 2022.</li>
<li>W. George et al. "IPv6 Support Required for All IP-Capable Nodes." RFC 6540, IETF, Apr. 2012.</li>
<li>P. Marks. "IPvFoo." https://github.com/pmarks-net/ipvfoo (accessed Oct. 14, 2026).</li>
<li>Microsoft. "Playwright documentation: Network." https://playwright.dev/docs/network (accessed Oct. 14, 2026).</li>
<li>AIORI-3 Hackathon Guidelines and Milestones. https://portal.aiori.in/aiori-3/hackathon-guideline (accessed Oct. 14, 2026).</li>
<li>Amazon Web Services. "New – AWS Public IPv4 Address Charge + Public IP Insights." AWS News Blog (charge effective Feb. 1, 2024).</li>
<li>Vercel Community. "IPv6 support." https://community.vercel.com/t/ipv6-support/5817 (accessed Oct. 30, 2026).</li>
<li>Y. Morishita, T. Jinmei. "Common Misbehavior Against DNS Queries for IPv6 Addresses." RFC 4074, IETF, May 2005.</li>
<li>S. Cheshire, M. Krochmal. "Special-Use Domain Names." RFC 6761, IETF, Feb. 2013.</li>
<li>R. Hinden, B. Haberman. "Unique Local IPv6 Unicast Addresses." RFC 4193, IETF, Oct. 2005.</li>
</ol>""")

slides.append(f"""<section class="slide title end"><div class="ttl" style="margin-top:220px">Thank You</div>
<div class="tname">V6Scope — every dependency, both protocols, honest answers.</div>
<div class="foot"><span>{e(FOOT)}</span><span>{len(slides)+1} / §TOTAL§</span></div></section>""")

CSS = """
@page{size:13.333in 7.5in;margin:0}
*{box-sizing:border-box}
body{margin:0;font-family:'Carlito','Calibri','DejaVu Sans',sans-serif;color:#151a22}
.slide{width:1280px;height:720px;padding:34px 56px 50px;position:relative;page-break-after:always;overflow:hidden;background:#fff}
.hdr{position:absolute;top:12px;left:0;right:0;text-align:center;font-size:12px;color:#1f2a8a}
.hdr b{color:#1f2a8a}
h1{color:#0a14c8;font-size:34px;margin:14px 0 4px;letter-spacing:-.2px}
.sub{font-size:16px;font-weight:700;margin-bottom:8px}
.body{margin-top:14px;font-size:18.5px;line-height:1.4}
.foot{position:absolute;bottom:14px;left:56px;right:56px;display:flex;justify-content:space-between;font-size:12px;color:#0a14c8}
.title{padding-top:50px}
.tcode{font-size:56px;font-weight:800;color:#0a14c8;margin-top:42px}
.ttl{font-size:30px;margin-top:8px;color:#222}
.tname{font-size:20px;color:#0a14c8;margin-top:6px;font-weight:700}
.tmeta{font-size:17px;margin-top:26px;line-height:1.5}
.end{text-align:center}.end .ttl{font-size:48px;font-weight:800;color:#0a14c8}
.cols2{display:grid;grid-template-columns:1fr 1fr;gap:26px}
.cols3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px}
.lead{font-size:17px;margin-top:0}
.pts{padding-left:18px;margin:6px 0}.pts li{margin-bottom:7px}
.callout{background:#f3f5ff;border:1px solid #d5dbff;border-radius:10px;padding:14px 16px}
.ctitle{font-weight:800;color:#0a14c8;margin-bottom:6px}
table.t{width:100%;border-collapse:collapse;font-size:16.5px}
table.t th{background:#0a14c8;color:#fff;text-align:left;padding:6px 8px;font-weight:700}
table.t td{border-bottom:1px solid #dfe3ee;padding:6px 8px;vertical-align:top}
table.t.small td,table.t.small th,.small{font-size:15px}
.mono,code{font-family:'DejaVu Sans Mono',monospace;font-size:13.5px}
.muted{color:#5d6672}
h3{color:#0a14c8;font-size:19px;margin:0 0 6px}
.six{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.six div{border:1px solid #d5dbff;border-radius:10px;padding:18px 20px;font-size:18px;background:#fafbff;min-height:170px}
.chip{display:inline-block;font-size:13px;font-weight:800;padding:1px 8px;border-radius:999px;white-space:nowrap}
.c-IPv6_OK{color:#17803d;background:#e6f4ea}.c-FAIL_DNS{color:#7b3fbf;background:#f1e9fb}.c-FAIL_TCP{color:#c62828;background:#fdecec}
.c-FAIL_TLS{color:#d9480f;background:#fdeee6}.c-FAIL_HTTP{color:#b5179e;background:#fbe7f6}.c-INCONCLUSIVE{color:#555e6a;background:#eef0f3}
.hid{font-size:12px;font-weight:800;color:#c62828;border:1.5px solid #c62828;border-radius:4px;padding:0 5px}
.tag{font-size:12px;font-weight:800;padding:1px 6px;border-radius:4px;letter-spacing:.03em;white-space:nowrap}
.t-impl{background:#e6edff;color:#1849a9}.t-test{background:#e6f4ea;color:#17803d}.t-plan{background:#eef0f3;color:#555}.t-pend{background:#fff3d6;color:#8a5a00}
.flow{display:grid;grid-template-columns:repeat(6,1fr);gap:10px}
.flow div{border:1.5px solid #0a14c8;border-radius:10px;padding:12px;font-size:15.5px;position:relative;background:#fafbff}
.flow b{display:block;color:#0a14c8;font-size:17px;margin-bottom:4px}
.flow div:not(:last-child)::after{content:'▶';position:absolute;right:-13px;top:40%;color:#0a14c8;font-size:12px}
.kpi{border:1px solid #d5dbff;border-radius:10px;padding:10px 14px;background:#fafbff}
.kpi .v{font-size:34px;font-weight:800;color:#0a14c8}.kpi .l{font-size:15px;color:#444}
.okt{color:#17803d;font-weight:800}.badt{color:#c62828;font-weight:800}
.arch{position:relative;height:470px}
.archz{zoom:1.14}
.t.tiny td,.t.tiny th{font-size:13.5px;padding:4px 7px}
.callout.tiny{font-size:14px}
.box{position:absolute;border:1.5px solid #222;border-radius:9px;padding:8px 10px;background:#fff;font-size:14px;line-height:1.25}
.box small{font-size:12px;color:#333}
.box.main{border-color:#0a14c8;background:#f3f5ff}.box.db{border-color:#555;background:#f6f6f6}
.box.v4{border-color:#1849a9;background:#eef3ff}.box.v6{border-color:#17803d;background:#ecf8f0}
.box.lab{border-color:#d9480f;background:#fff4ec}.box.inet{border-style:dashed}.box.user{border-style:dashed}
.grp{position:absolute;border:1.5px dashed #555;border-radius:12px}
.glabel{position:absolute;top:6px;left:12px;font-size:13px;font-weight:800;color:#0a14c8}
.arrow{position:absolute;height:2px;background:#222}.arrow::after{content:'';position:absolute;right:-1px;top:-5px;border:6px solid transparent;border-left:9px solid #222}
.dfd{display:flex;align-items:stretch;gap:10px}
.dfd>div{font-size:17px}
.dfd small{font-size:14.5px}
.dfd{margin-bottom:10px}
.proc{flex:1;border:1.5px solid #0a14c8;border-radius:16px;padding:10px 12px;background:#f3f5ff}
.ext{border:1.5px solid #222;padding:14px 12px;font-weight:800;min-width:110px;text-align:center}
.store{border-top:2px solid #222;border-bottom:2px solid #222;padding:10px 12px;min-width:150px;background:#f6f6f6}
.ar{align-self:center;color:#0a14c8;font-weight:800;white-space:nowrap}
figure{margin:0}figcaption{font-size:15.5px;color:#333;margin-top:8px}
.bib{font-size:15px;line-height:1.38;columns:2;column-gap:36px;padding-left:22px;margin:0}.bib li{margin-bottom:4px;break-inside:avoid}
.missing{border:1px dashed red;padding:30px;color:red}
"""

total = len(slides)
doc = f"<!doctype html><html><head><meta charset='utf-8'><style>{CSS}</style></head><body>{''.join(slides).replace('§TOTAL§', str(total))}</body></html>"
(DOCS / "deck.html").write_text(doc)

from playwright.sync_api import sync_playwright  # noqa: E402

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page()
    pg.set_content(doc, wait_until="load")
    pg.pdf(path=str(OUT), width="13.333in", height="7.5in", print_background=True,
           margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
    b.close()
print(f"wrote {OUT} ({total} pages) from {len(v6runs)} IPv6 runs + {len(v4runs)} no-IPv6 runs")
