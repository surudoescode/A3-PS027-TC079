#!/usr/bin/env bash
# One-shot installer for V6Scope on Ubuntu 24.04 (AWS EC2 in a DUAL-STACK subnet).
# Installs: backend API + dashboard (systemd: v6scope-api), the controlled lab (systemd: v6lab),
# nginx listening on IPv4 AND IPv6. Run as: sudo bash deploy/setup_ec2.sh
set -euo pipefail
APP=/opt/v6scope
SRC="$(cd "$(dirname "$0")/.." && pwd)"

apt-get update -q
DEBIAN_FRONTEND=noninteractive apt-get install -y -q python3-venv python3-pip libnss3-tools nginx iproute2

# --- code + virtualenv ---------------------------------------------------------------
mkdir -p $APP && rsync -a --delete --exclude data --exclude 'lab/logs' "$SRC/" $APP/
python3 -m venv $APP/venv
$APP/venv/bin/pip install -q -r $APP/backend/requirements.txt -r $APP/lab/requirements.txt
PLAYWRIGHT_BROWSERS_PATH=$APP/browsers $APP/venv/bin/playwright install --with-deps chromium
mkdir -p $APP/data

# --- lab certificates + browser trust for the lab CA -----------------------------------
(cd $APP/lab && $APP/venv/bin/python -c "import lab; lab.ensure_certs()")
NSS=$APP/data/browser-home/.pki/nssdb; mkdir -p $NSS
[ -f $NSS/cert9.db ] || certutil -d sql:$NSS -N --empty-password
certutil -d sql:$NSS -D -n v6lab 2>/dev/null || true
certutil -d sql:$NSS -A -t "C,," -n v6lab -i $APP/lab/certs/ca.pem

# --- systemd units ----------------------------------------------------------------------
cat > /etc/systemd/system/v6lab.service <<UNIT
[Unit]
Description=V6Lab controlled IPv6 fault website (DNS 127.0.0.1:5300, HTTPS on loopback)
After=network-online.target
[Service]
ExecStartPre=/bin/sh $APP/lab/setup_net.sh
ExecStart=$APP/venv/bin/python -u $APP/lab/lab.py --dns-port 5300
WorkingDirectory=$APP/lab
Restart=on-failure
[Install]
WantedBy=multi-user.target
UNIT

cat > /etc/systemd/system/v6scope-api.service <<UNIT
[Unit]
Description=V6Scope API + dashboard
After=network-online.target v6lab.service
[Service]
Environment=PLAYWRIGHT_BROWSERS_PATH=$APP/browsers
Environment=V6SCOPE_DB=$APP/data/v6scope.db
Environment=V6SCOPE_ARTIFACTS=$APP/data/artifacts
Environment=V6SCOPE_LAB_NAMESERVER=127.0.0.1:5300
Environment=V6SCOPE_EXTRA_CA=$APP/lab/certs/ca.pem
Environment=V6SCOPE_BROWSER_HOME=$APP/data/browser-home
WorkingDirectory=$APP/backend
ExecStart=$APP/venv/bin/uvicorn v6scope.api:app --host 127.0.0.1 --port 8000
Restart=on-failure
[Install]
WantedBy=multi-user.target
UNIT

# --- nginx: serve the dashboard on IPv4 and IPv6 -------------------------------------------
cat > /etc/nginx/sites-available/v6scope <<'NGX'
server {
    listen 80 default_server;
    listen [::]:80 default_server;      # the auditor itself is reachable over IPv6
    server_name _;
    client_max_body_size 1m;
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 120s;
    }
}
NGX
ln -sf /etc/nginx/sites-available/v6scope /etc/nginx/sites-enabled/v6scope
rm -f /etc/nginx/sites-enabled/default

systemctl daemon-reload
systemctl enable --now v6lab v6scope-api
nginx -t && systemctl restart nginx
sleep 3
echo; echo "Vantage self-test:"; curl -s http://127.0.0.1:8000/api/vantage | python3 -m json.tool | head -30
echo; echo "Public URLs:"
echo "  http://$(curl -s -4 https://ifconfig.co || echo '<public-ipv4>')/"
echo "  http://[$(ip -6 addr show scope global | awk '/inet6/{print $2}' | cut -d/ -f1 | head -1)]/"
