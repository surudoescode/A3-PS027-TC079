#!/bin/sh
# Boot an IPv6-capable Linux kernel (QEMU/TCG) that shares this workspace's filesystem, run job.sh inside it.
cd /home/claude/vm
timeout ${VM_TIMEOUT:-1500} qemu-system-x86_64 -m 3072 -cpu max -smp 1 -nographic -no-reboot \
  -kernel ex/boot/vmlinuz-6.8.0-147-generic -initrd initrd.gz \
  -append "console=ttyS0 quiet panic=-1 ipv6.disable=0" \
  \
  -nic none -virtfs local,path=/,mount_tag=hostroot,security_model=passthrough,id=r0,multidevs=remap
