#!/bin/sh
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin HOME=/root PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers
BB=/home/claude/vm/busybox
mkdir -p /dev/pts && mount -t devpts devpts /dev/pts 2>/dev/null
$BB ip link set lo up
echo "=== VM kernel: $(uname -r)"; ls /proc/net | head -50 | tr "\n" " "; echo; cat /proc/net/if_inet6; cat /proc/cmdline
if [ -x /home/claude/vm/job.sh ]; then sh /home/claude/vm/job.sh > /home/claude/vm/job.log 2>&1; echo "job exit $?"; fi
sync; $BB poweroff -f
