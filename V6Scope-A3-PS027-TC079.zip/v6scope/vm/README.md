# Running the simulation where the host kernel has IPv6 disabled

Some cloud sandboxes boot with `ipv6.disable=1`. We validated V6Scope there by booting a stock Ubuntu
6.8 kernel under QEMU (no KVM needed) with the host's root filesystem shared read/write over virtio-9p,
so the VM runs the exact same code with a real IPv6 stack.

1. `apt-get install qemu-system-x86 busybox-static zstd`; `apt-get download linux-image-6.8.0-*-generic linux-modules-6.8.0-*-generic` and `dpkg-deb -x` both into `vm/ex/`.
2. Build an initramfs with busybox + the `netfs 9pnet 9pnet_virtio 9p` modules and `initrd-init` as `/init`.
3. Put the commands to run in `vm/job.sh` (e.g. `sh lab/setup_net.sh && python3 scripts/run_simulation.py`) and run `./boot.sh`.

On EC2 or any normal Linux/WSL2 machine this is unnecessary — run the lab and simulation directly.
