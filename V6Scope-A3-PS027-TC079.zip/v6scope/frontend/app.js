/* V6Scope dashboard — plain JS, no build step. Talks to the FastAPI backend at /api. */
const API = (window.V6SCOPE_API || "").replace(/\/$/, "");
const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const CLASSES = ["IPv6_OK", "FAIL_DNS", "FAIL_TCP", "FAIL_TLS", "FAIL_HTTP", "INCONCLUSIVE"];
const CLASS_LABEL = { IPv6_OK: "IPv6 OK", FAIL_DNS: "DNS failure", FAIL_TCP: "TCP failure", FAIL_TLS: "TLS failure", FAIL_HTTP: "HTTP failure", INCONCLUSIVE: "Inconclusive" };
const cssVar = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const CLASS_VAR = { IPv6_OK: "--ok", FAIL_DNS: "--dns", FAIL_TCP: "--tcp", FAIL_TLS: "--tls", FAIL_HTTP: "--http", INCONCLUSIVE: "--inc" };
const VERDICT = {
  IPV6_READY: ["good", "IPv6 ready", "The page and every dependency loaded over IPv6."],
  HIDDEN_IPV6_FAILURES: ["bad", "Hidden IPv6 failures found", "The page works over IPv4, but some of its dependencies fail when only IPv6 is available."],
  PAGE_NOT_IPV6_READY: ["bad", "Page not reachable over IPv6", "The main document itself fails over IPv6."],
  PARTIAL: ["inc", "Partially verified", "Some resources could not be verified either way."],
  SCANNER_HAS_NO_IPV6: ["inc", "Scanner has no IPv6 — transport results inconclusive", "This scanner could not reach any IPv6 test anchor, so TCP/TLS/HTTP failures over IPv6 are not blamed on the site. DNS-level facts (missing AAAA) are still reported."],
  NO_DATA: ["inc", "No data", ""],
};

async function api(path, opts) {
  const r = await fetch(API + path, opts);
  if (!r.ok) throw new Error((await r.text()) || r.statusText);
  return r.json();
}

/* ------------------------------------------------------------------ router */
let pollTimer = null;
window.addEventListener("hashchange", route);
window.addEventListener("load", () => { route(); loadVantage(); });
function route() {
  clearTimeout(pollTimer);
  closeDrawer();
  const m = location.hash.match(/^#\/scan\/(.+)$/);
  if (m) return viewScan(decodeURIComponent(m[1]));
  viewHome();
}

async function loadVantage() {
  const el = $("#vantage");
  try {
    const v = await api("/api/vantage");
    const v6 = v.v6 && v.v6.ok, v4 = v.v4 && v.v4.ok;
    el.textContent = `This server: IPv4 ${v4 ? "✓" : "✗"} · IPv6 ${v6 ? "✓" : "✗"}`;
    el.className = "vantage " + (v6 && v4 ? "good" : "bad");
    el.title = `${v.v4.detail}\n${v.v6.detail}\nResolver: ${v.resolver}`;
  } catch (e) { el.textContent = "Scanner status unknown"; }
}

/* -------------------------------------------------------------------- home */
async function viewHome() {
  const app = $("#app");
  app.innerHTML = `
  <div class="grid g-scan">
    <section class="panel">
      <h2>New scan</h2>
      <p class="muted small">One URL per line (up to 50). Each page is opened in a real browser as an IPv4-only and as an IPv6-only visitor, then every dependency is tested over IPv4 and IPv6 separately: DNS → TCP → TLS → HTTP.</p>
      <textarea id="urls" rows="7" placeholder="https://www.example.com/&#10;https://another-site.in/"></textarea>
      <div class="row" style="margin-top:10px">
        <button class="primary" id="go">Start scan</button>
        <button id="demo" title="The controlled V6Lab site (only resolvable where the lab is running)">Use V6Lab demo URL</button>
        <span class="spacer"></span><span id="msg" class="small muted"></span>
      </div>
      <div class="notice"><b>How to read results.</b> <span class="chip c-IPv6_OK">IPv6_OK</span> works over IPv6 ·
        <span class="chip c-FAIL_DNS">FAIL_DNS</span> no AAAA ·
        <span class="chip c-FAIL_TCP">FAIL_TCP</span> address unreachable ·
        <span class="chip c-FAIL_TLS">FAIL_TLS</span> certificate/handshake ·
        <span class="chip c-FAIL_HTTP">FAIL_HTTP</span> server error ·
        <span class="chip c-INCONCLUSIVE">INCONCLUSIVE</span> not enough evidence.
        <span class="hidden-tag">v4 ✓ v6 ✗</span> marks a <b>hidden</b> failure: works over IPv4, fails over IPv6.</div>
    </section>
    <section class="panel">
      <div class="row"><h2 style="margin:0">Scan history</h2><span class="spacer"></span><button id="refresh">Refresh</button></div>
      <div id="hist" style="margin-top:8px"><div class="empty">Loading…</div></div>
    </section>
  </div>`;
  $("#demo").onclick = () => { $("#urls").value = "https://www.v6lab.test/"; };
  $("#refresh").onclick = loadHistory;
  $("#go").onclick = async () => {
    const urls = $("#urls").value.split(/\s+/).map(s => s.trim()).filter(Boolean);
    if (!urls.length) return;
    $("#go").disabled = true; $("#msg").textContent = "Queuing…";
    try {
      const r = await api("/api/scans", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ urls }) });
      if (r.scans.length === 1) location.hash = "#/scan/" + r.scans[0].id;
      else { $("#msg").textContent = `${r.scans.length} scans queued`; loadHistory(); }
    } catch (e) { $("#msg").textContent = "Error: " + e.message; }
    $("#go").disabled = false;
  };
  loadHistory();
}

async function loadHistory() {
  const el = $("#hist"); if (!el) return;
  const scans = await api("/api/scans");
  if (!scans.length) { el.innerHTML = `<div class="empty">No scans yet.</div>`; return; }
  el.innerHTML = `<table><thead><tr><th>When</th><th>Website</th><th>Result</th><th>IPv4 ok</th><th>IPv6 ok</th><th>Hidden</th></tr></thead><tbody>
    ${scans.map(s => {
      const su = s.summary || {};
      const st = s.status === "done" ? `<span class="chip ${verdictChip(su.verdict)}">${esc((VERDICT[su.verdict] || [, su.verdict])[1])}</span>`
        : s.status === "error" ? `<span class="chip c-FAIL_TCP">error</span>` : `<span class="spin"></span>${esc(s.status)}`;
      return `<tr class="click" onclick="location.hash='#/scan/${s.id}'">
        <td class="small muted">${esc(fmtTime(s.created_at))}</td>
        <td><div class="url">${esc(s.url)}</div>${s.label ? `<div class="small muted">${esc(s.label)}</div>` : ""}</td>
        <td>${st}</td>
        <td>${su.resources ? `${su.v4_ok}/${su.resources}` : ""}</td><td>${su.resources ? `${su.v6_ok}/${su.resources}` : ""}</td>
        <td>${su.hidden_v6_failures ?? ""}</td></tr>`;
    }).join("")}</tbody></table>`;
  if (scans.some(s => s.status === "queued" || s.status === "running")) pollTimer = setTimeout(loadHistory, 2500);
}
const verdictChip = v => ({ IPV6_READY: "c-IPv6_OK", HIDDEN_IPV6_FAILURES: "c-FAIL_TCP", PAGE_NOT_IPV6_READY: "c-FAIL_TCP" }[v] || "c-INCONCLUSIVE");
const fmtTime = t => t ? t.replace("T", " ").replace(/[+-]\d{4}$/, "") : "";

/* -------------------------------------------------------------------- scan */
let current = null, filter = "ALL";
async function viewScan(id) {
  const app = $("#app");
  let s;
  try { s = await api("/api/scans/" + encodeURIComponent(id)); }
  catch (e) { app.innerHTML = `<div class="panel empty">Scan not found. <a href="#/">Back</a></div>`; return; }
  current = s;
  if (s.status !== "done") {
    app.innerHTML = `<p><a href="#/">← All scans</a></p><div class="panel">
      <h1 class="url">${esc(s.url)}</h1>
      ${s.status === "error" ? `<p class="badt">Scan failed: ${esc(s.error)}</p>` :
        `<p><span class="spin"></span>${esc(s.progress || s.status)}</p>${pipeline(s)}`}</div>`;
    if (s.status !== "error") pollTimer = setTimeout(() => viewScan(id), 1500);
    return;
  }
  const su = s.summary, v = VERDICT[su.verdict] || ["inc", su.verdict, ""];
  const hidden = s.resources.filter(r => r.comparison === "hidden_v6_failure");
  app.innerHTML = `
    <p><a href="#/">← All scans</a></p>
    <div class="row"><div><h1 class="url" style="font-size:18px">${esc(s.url)}</h1>
      <div class="small muted">Scan ${esc(s.id)} · ${esc(fmtTime(s.finished_at))} · discovery: ${esc(su.discovery_method)}${s.label ? " · " + esc(s.label) : ""}</div></div>
      <span class="spacer"></span>
      <a class="btn" href="${API}/api/scans/${s.id}/report.csv">⬇ CSV report</a>
      <a class="btn" href="${API}/api/scans/${s.id}/report.json">⬇ JSON report</a></div>
    ${pipeline(s)}
    <div class="verdict ${v[0]}"><div><div class="big">${esc(v[1])}</div><div class="muted">${esc(v[2])}
      ${hidden.length ? ` <b>${hidden.length} of ${su.resources}</b> resources load over IPv4 but fail over IPv6.` : ""}</div></div></div>
    <div class="kpis">
      ${kpi(su.resources, "resources discovered")}${kpi(su.hosts, `hosts (${su.third_party_hosts} third-party)`)}
      ${kpi(su.v4_rate + "%", `IPv4 success (${su.v4_ok}/${su.resources})`, su.v4_rate === 100 ? "good" : "")}
      ${kpi(su.v6_rate + "%", `IPv6 success (${su.v6_ok}/${su.resources})`, su.v6_rate < 100 ? "alert" : "good")}
      ${kpi(su.hidden_v6_failures, "hidden IPv6 failures", su.hidden_v6_failures ? "alert" : "good")}
      ${kpi(su.inconclusive, "inconclusive")}
    </div>
    <div class="grid g2" style="margin-top:16px">
      <section class="panel"><h2>Failure categories</h2><div class="bars">${CLASSES.map(c => bar(c, su.classes[c] || 0, su.resources)).join("")}</div>
        <h3 style="margin-top:16px">Scanner vantage point</h3>${vantageBox(s.vantage)}</section>
      <section class="panel"><h2>What users see</h2>${shots(s)}</section>
    </div>
    <section class="panel" style="margin-top:16px">
      <div class="row"><h2 style="margin:0">Dependency map</h2><span class="spacer"></span><span class="small muted">click a node for evidence · page → hosts → resources · dashed = loaded by another resource</span></div>
      <div id="cy" style="margin-top:10px"></div>
      <div class="legend">${CLASSES.map(c => `<span><span class="sw" style="background:${cssVar(CLASS_VAR[c])}"></span>${CLASS_LABEL[c]}</span>`).join("")}
        <span><span class="sw" style="border:2px solid ${cssVar("--tcp")};background:transparent"></span>thick red ring = works on IPv4, fails on IPv6</span></div>
    </section>
    <section class="panel" style="margin-top:16px">
      <h2>Resources</h2><div class="filters" id="filters"></div><div id="rtable"></div>
    </section>`;
  renderFilters(); renderTable(); drawGraph(s);
}

const kpi = (v, l, cls = "") => `<div class="kpi ${cls}"><div class="v">${esc(v)}</div><div class="l">${esc(l)}</div></div>`;
const bar = (c, n, tot) => `<div class="bar"><span><span class="chip c-${c}">${c}</span></span><div class="track"><div class="fill" style="width:${tot ? 100 * n / tot : 0}%;background:${cssVar(CLASS_VAR[c])}"></div></div><b>${n}</b></div>`;

function pipeline(s) {
  const steps = ["URL submitted", "Scanner self-test", "Dependency discovery", "IPv4 tests", "IPv6 tests", "Comparison", "Diagnosis", "Report"];
  const p = (s.progress || "").toLowerCase();
  let reached = s.status === "done" ? steps.length : s.vantage ? (s.discovery ? 5 : 2) : 1;
  if (p.includes("discover")) reached = Math.max(reached, 2);
  return `<div class="pipeline">${steps.map((x, i) => `<span class="${i < reached ? "done" : ""}">${x}</span>`).join("")}</div>`;
}

function vantageBox(v) {
  if (!v) return "";
  const line = f => { const x = v[f] || {}; return `<div>IPv${f.slice(1)}</div><div>${x.ok ? '<span class="okt">available</span>' : '<span class="badt">not available</span>'} <span class="muted small">— ${esc(x.detail || "")}</span></div>`; };
  return `<div class="kv">${line("v4")}${line("v6")}<div>Resolver</div><div class="mono">${esc(v.resolver)}</div><div>Host</div><div class="mono">${esc(v.hostname)}</div></div>`;
}

function shots(s) {
  const views = (s.discovery && s.discovery.views) || {};
  if (!views.v4 && !views.v6) return `<p class="muted">Browser views not available for this scan (${esc(s.discovery && s.discovery.method)}).</p>`;
  const fig = (k, title) => {
    const vw = views[k] || {};
    return `<figure>${vw.screenshot ? `<a href="${API}/api/scans/${s.id}/screenshot/${k}" target="_blank"><img src="${API}/api/scans/${s.id}/screenshot/${k}" alt="${title}"></a>` : `<div class="empty">no screenshot</div>`}
      <figcaption><b>${title}</b> — ${vw.request_count ?? "?"} requests, <span class="${vw.failed_count ? "badt" : "okt"}">${vw.failed_count ?? "?"} failed</span>${vw.page_error ? ` · page error: ${esc(vw.page_error)}` : ""}</figcaption></figure>`;
  };
  return `<p class="muted small">Real Chromium, with every hostname pinned to its IPv4 address (left) or its IPv6 address (right).</p>
    <div class="shots">${fig("v4", "As an IPv4-only visitor")}${fig("v6", "As an IPv6-only visitor")}</div>`;
}

function renderFilters() {
  const counts = { ALL: current.resources.length, HIDDEN: current.resources.filter(r => r.comparison === "hidden_v6_failure").length };
  CLASSES.forEach(c => counts[c] = current.resources.filter(r => r.ipv6_class === c).length);
  $("#filters").innerHTML = ["ALL", "HIDDEN", ...CLASSES].filter(k => k === "ALL" || counts[k]).map(k =>
    `<button class="${filter === k ? "on" : ""}" data-k="${k}">${k === "HIDDEN" ? "Hidden (v4 ✓ v6 ✗)" : k === "ALL" ? "All" : k} · ${counts[k]}</button>`).join("");
  $("#filters").querySelectorAll("button").forEach(b => b.onclick = () => { filter = b.dataset.k; renderFilters(); renderTable(); });
}

function ladder(l) {
  if (!l) return "";
  return `<span class="ladder">${["dns", "tcp", "tls", "http"].map(k => `<i class="${l[k] === "ok" ? "ok" : l[k] === "fail" ? "fail" : "na"}" title="${k.toUpperCase()}: ${l[k]}">${k.toUpperCase()}</i>`).join("")}</span>`;
}

function renderTable() {
  const rows = current.resources.filter(r => filter === "ALL" || (filter === "HIDDEN" ? r.comparison === "hidden_v6_failure" : r.ipv6_class === filter));
  $("#rtable").innerHTML = `<table><thead><tr><th>IPv6 result</th><th>Type</th><th>Resource</th><th>IPv4 stages</th><th>IPv6 stages</th><th>Diagnosis</th></tr></thead><tbody>
    ${rows.map(r => `<tr class="click" data-id="${r.id}">
      <td><span class="chip c-${r.ipv6_class}">${r.ipv6_class}</span>${r.comparison === "hidden_v6_failure" ? '<span class="hidden-tag">v4 ✓ v6 ✗</span>' : ""}</td>
      <td class="small">${esc(r.rtype)}<div class="muted">${esc(r.party)}-party</div></td>
      <td><div class="url">${esc(r.url)}</div></td>
      <td>${ladder(r.diagnosis.ladder.v4)}</td><td>${ladder(r.diagnosis.ladder.v6)}</td>
      <td class="small">${esc(r.diagnosis.title)}</td></tr>`).join("")}</tbody></table>`;
  $("#rtable").querySelectorAll("tr.click").forEach(tr => tr.onclick = () => openDrawer(+tr.dataset.id));
}

/* ------------------------------------------------------------------ graph */
function drawGraph(s) {
  if (!window.cytoscape) { $("#cy").innerHTML = `<div class="empty">Graph library not loaded.</div>`; return; }
  const els = [], page = s.resources[0];
  const short = u => { try { const x = new URL(u); return (x.pathname.split("/").filter(Boolean).pop() || "/") } catch { return u } };
  const worst = s.summary.host_status || {};
  els.push({ data: { id: "page", label: "PAGE\n" + new URL(s.url).hostname, cls: page.ipv6_class, kind: "page", rid: page.id } });
  const hosts = [...new Set(s.resources.map(r => r.host))];
  hosts.forEach(h => {
    const rs = s.resources.filter(r => r.host === h);
    const hid = rs.some(r => r.comparison === "hidden_v6_failure");
    const d = (rs[0].v6 || {}).dns || {};
    els.push({ data: { id: "h:" + h, label: h + "\n" + (d.addresses && d.addresses.length ? "AAAA ✓" : "AAAA ✗"), cls: worst[h], kind: "host", hidden: hid ? 1 : 0 } });
    els.push({ data: { id: "e:page:" + h, source: "page", target: "h:" + h } });
  });
  const ids = new Map(s.resources.map(r => [r.url, r]));
  s.resources.slice(1).forEach(r => {
    els.push({ data: { id: "r:" + r.id, label: `${r.rtype}\n${short(r.url)}`, cls: r.ipv6_class, kind: "res", rid: r.id, hidden: r.comparison === "hidden_v6_failure" ? 1 : 0 } });
    els.push({ data: { id: "e:h:" + r.id, source: "h:" + r.host, target: "r:" + r.id } });
    const parent = r.referer && ids.get(r.referer);
    if (parent && parent.id !== page.id) els.push({ data: { id: "e:ref:" + r.id, source: "r:" + parent.id, target: "r:" + r.id, ref: 1 } });
  });
  const col = c => cssVar(CLASS_VAR[c] || "--inc");
  const cy = cytoscape({
    container: $("#cy"), elements: els, wheelSensitivity: 0.2,
    style: [
      { selector: "node", style: { "label": "data(label)", "text-wrap": "wrap", "font-size": 10, "color": cssVar("--ink"), "text-valign": "bottom", "text-margin-y": 4, "background-color": e => col(e.data("cls")), "width": 22, "height": 22, "font-family": "system-ui, sans-serif" } },
      { selector: "node[kind='page']", style: { "shape": "round-rectangle", "width": 46, "height": 30, "font-weight": 700 } },
      { selector: "node[kind='host']", style: { "shape": "diamond", "width": 30, "height": 30, "font-weight": 600 } },
      { selector: "node[hidden=1]", style: { "border-width": 4, "border-color": cssVar("--tcp"), "border-style": "double" } },
      { selector: "edge", style: { "width": 1.4, "line-color": cssVar("--line"), "target-arrow-color": cssVar("--mut"), "target-arrow-shape": "triangle", "curve-style": "bezier", "arrow-scale": .7 } },
      { selector: "edge[ref=1]", style: { "line-style": "dashed", "line-color": cssVar("--accent-2"), "target-arrow-color": cssVar("--accent-2") } },
    ],
    layout: { name: "breadthfirst", directed: true, roots: "#page", spacingFactor: 1.15, padding: 24 },
  });
  cy.on("tap", "node", e => { const rid = e.target.data("rid"); if (rid) openDrawer(rid); });
}

/* ------------------------------------------------------------------ drawer */
function closeDrawer() { $("#drawer").hidden = true; $("#scrim").hidden = true; }
$("#scrim") && ($("#scrim").onclick = closeDrawer);
document.addEventListener("keydown", e => { if (e.key === "Escape") closeDrawer(); });

function stageCell(p, st) {
  if (!p) return "";
  const d = p.dns || {};
  if (st === "dns") return `${d.status === "OK" ? '<span class="okt">✓</span>' : '<span class="badt">✗ ' + esc(d.status) + "</span>"} ${esc(d.query)} ${esc((d.addresses || []).join(", "))}
    ${d.cnames && d.cnames.length ? `<div class="muted">CNAME ${esc(d.cnames.join(" → "))}</div>` : ""}${d.error && d.status !== "OK" ? `<div class="muted">${esc(d.error)}</div>` : ""}<div class="muted">${d.ms ?? "?"} ms</div>`;
  const a = (p.attempts || []).slice(-1)[0];
  if (!a) return '<span class="muted">not reached</span>';
  const x = a[st];
  if (!x) return st === "tls" && a.tcp && a.tcp.ok ? '<span class="muted">n/a (plain HTTP)</span>' : '<span class="muted">not reached</span>';
  let s = x.ok ? '<span class="okt">✓</span> ' : `<span class="badt">✗ ${esc(x.error_class || "")}</span> `;
  if (st === "tcp") s += `[${esc(a.address)}]:${a.port}${x.error ? `<div class="muted">${esc(x.error)}</div>` : ""}`;
  if (st === "tls") { const c = x.cert || {}; s += `${esc(x.version || "")} ${x.error ? `<div class="muted">${esc(x.error)}</div>` : ""}${c.san ? `<div class="muted">cert: ${esc((c.san || []).join(", ") || c.subject_cn)} · issuer ${esc(c.issuer_cn)}</div>` : ""}`; }
  if (st === "http") s += `${x.status ? `HTTP ${x.status} ${esc(x.reason || "")} · ${x.bytes} bytes` : esc(x.error || "")}${x.headers && x.headers.server ? `<div class="muted">server: ${esc(x.headers.server)}</div>` : ""}`;
  return s + `<div class="muted">${x.ms ?? "?"} ms</div>`;
}

function openDrawer(rid) {
  const r = current.resources.find(x => x.id === rid);
  if (!r) return;
  const dg = r.diagnosis, b = r.browser || {};
  const bv = k => { const x = b[k]; return !x ? '<span class="muted">not requested in this view</span>' : x.error ? `<span class="badt">${esc(x.error)}</span>` : `<span class="okt">HTTP ${esc(x.status)}</span>`; };
  $("#drawer").innerHTML = `
    <div class="row"><span class="chip c-${r.ipv6_class}">${r.ipv6_class}</span>${r.comparison === "hidden_v6_failure" ? '<span class="hidden-tag">works on IPv4 · fails on IPv6</span>' : ""}
      <span class="chip c-INCONCLUSIVE">confidence: ${esc(r.confidence)}</span><span class="spacer"></span><button onclick="closeDrawer()">Close ✕</button></div>
    <h2 style="margin-top:12px">${esc(dg.title)}</h2>
    <div class="url">${esc(r.url)}</div>
    <div class="small muted">${esc(r.rtype)} · ${esc(r.party)}-party · loaded by ${esc(r.referer || "—")}</div>
    <h3 style="margin-top:16px">What happened</h3><p>${esc(dg.cause)}</p>
    ${dg.explanation ? `<h3>Why it matters / likely cause</h3><p>${esc(dg.explanation)}</p>` : ""}
    ${dg.fix ? `<h3>Suggested fix</h3><p>${esc(dg.fix)}</p>` : ""}
    <h3>IPv4 vs IPv6, stage by stage</h3>
    <table class="cmp"><thead><tr><th>Stage</th><th>IPv4 (AF_INET socket)</th><th>IPv6 (AF_INET6 socket)</th></tr></thead><tbody>
      ${["dns", "tcp", "tls", "http"].map(st => `<tr><td class="st">${st.toUpperCase()}</td><td>${stageCell(r.v4, st)}</td><td>${stageCell(r.v6, st)}</td></tr>`).join("")}
      <tr><td class="st">Repeat</td><td>${esc(rep(r.v4))}</td><td>${esc(rep(r.v6))}</td></tr>
      <tr><td class="st">Browser</td><td>${bv("v4")}</td><td>${bv("v6")}</td></tr>
    </tbody></table>
    <h3>Evidence</h3><pre class="evidence">${esc((dg.evidence || []).join("\n"))}</pre>
    <details style="margin-top:12px"><summary>Raw probe data (JSON)</summary><pre class="evidence">${esc(JSON.stringify({ v4: r.v4, v6: r.v6 }, null, 2))}</pre></details>`;
  $("#drawer").hidden = false; $("#scrim").hidden = false;
  $("#scrim").onclick = closeDrawer;
}
const rep = p => !p ? "" : p.ok ? "not needed (passed first time)" : p.fail_stage === "dns" ? "DNS answer is definitive" :
  (p.repeats || []).length ? (p.consistent ? "same failure on repeat ✓" : "different on repeat → inconclusive") : "";
