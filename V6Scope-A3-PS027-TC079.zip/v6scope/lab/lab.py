#!/usr/bin/env python3
"""V6Lab — the controlled website with deliberately introduced IPv6 faults.

Runs, in one process:
  * an authoritative DNS server for v6lab.test (UDP+TCP, default 127.0.0.1:5300)
  * dual-stack HTTPS servers, one per hostname and address family, each behaving as
    defined in lab_hosts.py (correct, missing, refusing, wrong certificate, HTTP 503 …)

Prerequisite (root): ./setup_net.sh   — adds the fd00:6:1::/64 test addresses to `lo`.
Usage:  sudo python3 lab.py [--dns-port 5300] [--port 443]
Every request is written to lab/logs/access.log with the address family it arrived on,
which is independent proof of what the scanner actually did.
"""
from __future__ import annotations

import argparse
import asyncio
import datetime as dt
import ipaddress
import json
import os
import socket
import ssl
import sys
import threading
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID
from dnslib import AAAA, QTYPE, RCODE, RR, SOA, A, DNSRecord
from dnslib.server import BaseResolver, DNSServer

import lab_hosts as L

HERE = Path(__file__).resolve().parent
CERTS = HERE / "certs"
LOGS = HERE / "logs"
WWW = HERE / "www"


# ------------------------------------------------------------------ certificates
def _key():
    return ec.generate_private_key(ec.SECP256R1())


def _write(path: Path, key, cert):
    path.with_suffix(".key").write_bytes(key.private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    path.with_suffix(".pem").write_bytes(cert.public_bytes(serialization.Encoding.PEM))


def ensure_certs():
    CERTS.mkdir(exist_ok=True)
    if (CERTS / "ca.pem").exists() and (CERTS / "wrong.pem").exists():
        return
    now = dt.datetime.now(dt.timezone.utc)
    ca_key = _key()
    ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "V6Lab Test Root CA (V6ision)")])
    ca = (x509.CertificateBuilder().subject_name(ca_name).issuer_name(ca_name)
          .public_key(ca_key.public_key()).serial_number(x509.random_serial_number())
          .not_valid_before(now - dt.timedelta(days=1)).not_valid_after(now + dt.timedelta(days=825))
          .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
          .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True,
                                       content_commitment=False, key_encipherment=False, data_encipherment=False,
                                       key_agreement=False, encipher_only=False, decipher_only=False), critical=True)
          .add_extension(x509.SubjectKeyIdentifier.from_public_key(ca_key.public_key()), critical=False)
          .sign(ca_key, hashes.SHA256()))
    _write(CERTS / "ca", ca_key, ca)

    def leaf(fname, names):
        k = _key()
        c = (x509.CertificateBuilder()
             .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, names[0])]))
             .issuer_name(ca_name).public_key(k.public_key()).serial_number(x509.random_serial_number())
             .not_valid_before(now - dt.timedelta(days=1)).not_valid_after(now + dt.timedelta(days=397))
             .add_extension(x509.SubjectAlternativeName([x509.DNSName(n) for n in names]), critical=False)
             .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
             .add_extension(x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
             .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
             .sign(ca_key, hashes.SHA256()))
        _write(CERTS / fname, k, c)

    leaf("lab", [f"*.{L.ZONE}", L.ZONE])          # valid for every lab host
    leaf("wrong", [L.WRONG_CERT_NAME])               # trusted CA, wrong name -> mismatch
    print("generated lab CA and certificates in", CERTS)


def ssl_ctx(which: str) -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(CERTS / f"{which}.pem", CERTS / f"{which}.key")
    ctx.set_alpn_protocols(["http/1.1"])
    return ctx


# --------------------------------------------------------------------------- DNS
class LabResolver(BaseResolver):
    def resolve(self, request, handler):
        reply = request.reply()
        q = request.q
        name = str(q.qname).rstrip(".").lower()
        qt = QTYPE[q.qtype]
        if not (name == L.ZONE or name.endswith("." + L.ZONE)):
            reply.header.rcode = RCODE.REFUSED
            return reply
        key = name[: -len(L.ZONE) - 1] if name != L.ZONE else ""
        h = L.HOSTS.get(key)
        soa = RR(L.ZONE, QTYPE.SOA, ttl=60, rdata=SOA(f"ns.{L.ZONE}", f"hostmaster.{L.ZONE}", (1, 3600, 600, 86400, 60)))
        if h is None:
            reply.header.rcode = RCODE.NXDOMAIN
            reply.add_auth(soa)
        elif qt == "A":
            reply.add_answer(RR(name, QTYPE.A, ttl=60, rdata=A(h["a"])))
        elif qt == "AAAA":
            if h["v6"] == "aaaa_servfail":
                reply.header.rcode = RCODE.SERVFAIL          # C6: broken AAAA handling
            elif h["aaaa"]:
                reply.add_answer(RR(name, QTYPE.AAAA, ttl=60, rdata=AAAA(h["aaaa"])))
            else:
                reply.add_auth(soa)                           # C2: NOERROR + no data
        else:
            reply.add_auth(soa)
        log({"proto": "dns", "qname": name, "qtype": qt, "rcode": RCODE[reply.header.rcode],
             "answers": [str(r.rdata) for r in reply.rr]})
        return reply


# -------------------------------------------------------------------------- HTTP
_log_lock = threading.Lock()


def log(rec: dict):
    rec = {"ts": dt.datetime.now().isoformat(timespec="milliseconds"), **rec}
    with _log_lock, open(LOGS / "access.log", "a") as f:
        f.write(json.dumps(rec) + "\n")


CTYPES = {".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "application/javascript",
          ".svg": "image/svg+xml", ".ttf": "font/ttf", ".json": "application/json"}

ROUTES = {  # (host key, path) -> file in www/
    ("www", "/"): "index.html",
    ("ok", "/static/app.css"): "app.css",
    ("nov6", "/img/logo.svg"): "logo.svg",
    ("deadv6", "/js/analytics.js"): "analytics.js",
    ("badcert", "/fonts/brand.ttf"): "brand.ttf",
    ("err6", "/api/status.json"): "status.json",
    ("flakydns", "/img/partner-badge.svg"): "badge.svg",
}


def make_handler(key: str, family: int):
    behaviour = L.HOSTS[key]["v6"] if family == 6 else "ok"

    async def handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        peer = writer.get_extra_info("peername")
        try:
            head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 10)
        except Exception:
            writer.close()
            return
        lines = head.decode("iso-8859-1").split("\r\n")
        try:
            method, path, _ = lines[0].split(" ", 2)
        except ValueError:
            writer.close()
            return
        path = path.split("?")[0]
        hdrs = {k.lower(): v.strip() for k, _, v in (ln.partition(":") for ln in lines[1:] if ln)}
        ua = hdrs.get("user-agent", "")
        origin = hdrs.get("origin")
        if behaviour == "http_503":
            status, body, ctype = 503, b'{"error":"no healthy backend for IPv6 listener"}\n', "application/json"
        else:
            f = ROUTES.get((key, path))
            if f:
                status, body = 200, (WWW / f).read_bytes()
                ctype = CTYPES.get(Path(f).suffix, "application/octet-stream")
            else:
                status, body, ctype = 404, b"not found\n", "text/plain"
        if method == "HEAD":
            body_out = b""
        else:
            body_out = body
        h = [f"HTTP/1.1 {status} {'OK' if status == 200 else ('Service Unavailable' if status == 503 else 'Not Found')}",
             f"Server: v6lab/{key}-ipv{family}", f"Content-Type: {ctype}", f"Content-Length: {len(body)}",
             "Cache-Control: no-store", "Access-Control-Allow-Origin: *", "Connection: close", "", ""]
        writer.write("\r\n".join(h).encode() + body_out)
        log({"proto": "http", "family": family, "host": L.fqdn(key), "listen": writer.get_extra_info("sockname")[0],
             "peer": peer[0] if peer else None, "method": method, "path": path, "status": status,
             "client": "v6scope-probe" if ua.startswith("V6Scope") else ("chromium" if "Chrome" in ua else ua[:30]),
             "origin": origin})
        try:
            await writer.drain()
        finally:
            writer.close()

    return handle


def _v6_ok():
    try:
        socket.socket(socket.AF_INET6).close()
        return True
    except OSError:
        return False


async def serve(port: int):
    servers = []
    ok_ctx, wrong_ctx = ssl_ctx("lab"), ssl_ctx("wrong")
    for key, h in L.HOSTS.items():
        for fam in (4, 6):
            addr = h["a"] if fam == 4 else h["aaaa"]
            beh = "ok" if fam == 4 else h["v6"]
            if not addr:
                continue
            if fam == 6 and beh == "no_listener":
                if not socket.has_ipv6 or not _v6_ok():
                    continue
                print(f"  [{addr}]:{port:<5} {L.fqdn(key):<22} IPv6  (deliberately NOT listening)")
                continue
            ctx = wrong_ctx if (fam == 6 and beh == "wrong_cert") else ok_ctx
            try:
                srv = await asyncio.start_server(make_handler(key, fam), host=addr, port=port, ssl=ctx,
                                                 family=socket.AF_INET if fam == 4 else socket.AF_INET6,
                                                 reuse_address=True)
                servers.append(srv)
                print(f"  {addr if fam == 4 else '[' + addr + ']'}:{port:<5} {L.fqdn(key):<22} IPv{fam}  {beh}")
            except OSError as e:
                print(f"  ! could not listen on {addr}:{port} for {L.fqdn(key)} IPv{fam}: {e.strerror or e}"
                      + ("  (this host has no IPv6 — IPv6 side of the lab unavailable)" if fam == 6 else ""))
    print("V6Lab READY", flush=True)
    await asyncio.gather(*(s.serve_forever() for s in servers))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dns-port", type=int, default=int(os.environ.get("LAB_DNS_PORT", 5300)))
    ap.add_argument("--port", type=int, default=L.PORT)
    a = ap.parse_args()
    LOGS.mkdir(exist_ok=True)
    ensure_certs()
    res = LabResolver()
    for tcp in (False, True):
        DNSServer(res, address="127.0.0.1", port=a.dns_port, tcp=tcp).start_thread()
    print(f"V6Lab DNS for {L.ZONE} on 127.0.0.1:{a.dns_port} (UDP+TCP)")
    try:
        asyncio.run(serve(a.port))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    sys.exit(main())
