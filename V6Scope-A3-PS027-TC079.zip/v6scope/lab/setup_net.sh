#!/bin/sh
# Adds the V6Lab IPv6 test addresses (fd00:6:1::/64, RFC 4193 unique-local) to the loopback
# interface. IPv4 needs nothing: every 127.x.y.z address already belongs to `lo` on Linux.
# Usage: sudo ./setup_net.sh        (set IP=/path/to/busybox-ip if iproute2 is missing)
IP=${IP:-ip}
$IP link set lo up
for n in 10 11 13 14 15; do
  $IP -6 addr add fd00:6:1::$n/128 dev lo 2>/dev/null || true
done
$IP -6 addr show dev lo
