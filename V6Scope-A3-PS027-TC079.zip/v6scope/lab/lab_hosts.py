"""The controlled test site ("answer-key website").

Zone v6lab.test uses the .test TLD reserved for testing by RFC 6761, so it can never
collide with a real domain. Each hostname gets its own IPv4 loopback address (any
127.x.y.z works on Linux) and its own IPv6 unique-local address (fd00:6:1::/64, RFC 4193)
added to the loopback interface by setup_net.sh.

Every resource works over IPv4. The IPv6 side of each one is broken in exactly one,
deliberately chosen way, so we know the correct answer before the scan runs.
"""
ZONE = "v6lab.test"
PORT = 443

# v6 behaviour:  ok | no_aaaa | no_listener | wrong_cert | http_503 | aaaa_servfail
HOSTS = {
    "www":      {"a": "127.0.0.10", "aaaa": "fd00:6:1::10", "v6": "ok"},
    "ok":       {"a": "127.0.0.11", "aaaa": "fd00:6:1::11", "v6": "ok"},
    "nov6":     {"a": "127.0.0.12", "aaaa": None,           "v6": "no_aaaa"},
    "deadv6":   {"a": "127.0.0.13", "aaaa": "fd00:6:1::13", "v6": "no_listener"},
    "badcert":  {"a": "127.0.0.14", "aaaa": "fd00:6:1::14", "v6": "wrong_cert"},
    "err6":     {"a": "127.0.0.15", "aaaa": "fd00:6:1::15", "v6": "http_503"},
    "flakydns": {"a": "127.0.0.16", "aaaa": None,           "v6": "aaaa_servfail"},
}

# name presented by the deliberately wrong certificate on badcert's IPv6 listener
WRONG_CERT_NAME = "legacy-cdn.example.net"


def fqdn(key: str) -> str:
    return f"{key}.{ZONE}"


def url(key: str, path: str) -> str:
    return f"https://{fqdn(key)}{'' if PORT == 443 else f':{PORT}'}{path}"


# The answer key. "expected" is what a correct auditor must report for the IPv6 side.
CASES = [
    {"case": "C0", "name": "Main page (HTML document)", "url": url("www", "/"), "rtype": "document",
     "fault": "none — page itself is dual-stack", "expected": "IPv6_OK", "expected_v4": True},
    {"case": "C1", "name": "Control: works on IPv4 and IPv6", "url": url("ok", "/static/app.css"),
     "rtype": "stylesheet", "fault": "none", "expected": "IPv6_OK", "expected_v4": True},
    {"case": "C2", "name": "IPv4 address but no IPv6 address", "url": url("nov6", "/img/logo.svg"),
     "rtype": "image", "fault": "A record only, no AAAA record", "expected": "FAIL_DNS", "expected_v4": True},
    {"case": "C3", "name": "IPv6 address published but unreachable over TCP", "url": url("deadv6", "/js/analytics.js"),
     "rtype": "script", "fault": "AAAA points to an address with no listener on 443 (TCP RST)",
     "expected": "FAIL_TCP", "expected_v4": True},
    {"case": "C4", "name": "TLS certificate mismatch over IPv6", "url": url("badcert", "/fonts/brand.ttf"),
     "rtype": "font", "fault": f"IPv6 listener presents a certificate for {WRONG_CERT_NAME}",
     "expected": "FAIL_TLS", "expected_v4": True},
    {"case": "C5", "name": "HTTP error over IPv6 only", "url": url("err6", "/api/status.json"),
     "rtype": "fetch", "fault": "IPv6 virtual host answers 503; IPv4 answers 200", "expected": "FAIL_HTTP",
     "expected_v4": True},
    {"case": "C6", "name": "Honesty check: AAAA lookup SERVFAIL", "url": url("flakydns", "/img/partner-badge.svg"),
     "rtype": "image", "fault": "DNS server returns SERVFAIL for the AAAA query (RFC 4074-style broken server)",
     "expected": "INCONCLUSIVE", "expected_v4": True},
]
