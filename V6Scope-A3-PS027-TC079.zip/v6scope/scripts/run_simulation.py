#!/usr/bin/env python3
"""End-to-end simulation: start V6Lab, scan it with V6Scope, compare against the answer key.

    sudo ./lab/setup_net.sh            # once per boot: IPv6 test addresses on lo
    sudo python3 scripts/run_simulation.py

Nothing is hard-coded about the outcome: the scan runs the normal V6Scope pipeline
(vantage self-test → browser discovery → per-family DNS/TCP/TLS/HTTP probes → diagnosis)
and the result is stored in the same database the dashboard reads. The lab's own access
log is then used as independent evidence of which requests arrived over which protocol.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "lab"))
sys.path.insert(0, str(ROOT / "backend"))
import lab_hosts as L  # noqa: E402

DNS_PORT = int(os.environ.get("LAB_DNS_PORT", 5300))


def prepare_browser_home() -> str | None:
    """Chromium reads trusted CAs from $HOME/.pki/nssdb; add the lab CA there."""
    home = ROOT / "data" / "browser-home"
    db = home / ".pki" / "nssdb"
    if not shutil.which("certutil"):
        print("! certutil (libnss3-tools) not found: the browser will not trust the lab CA")
        return None
    db.mkdir(parents=True, exist_ok=True)
    if not (db / "cert9.db").exists():
        subprocess.run(["certutil", "-d", f"sql:{db}", "-N", "--empty-password"], check=True)
    subprocess.run(["certutil", "-d", f"sql:{db}", "-D", "-n", "v6lab"], capture_output=True)
    subprocess.run(["certutil", "-d", f"sql:{db}", "-A", "-t", "C,,", "-n", "v6lab",
                    "-i", str(ROOT / "lab" / "certs" / "ca.pem")], check=True)
    return str(home)


def start_lab():
    proc = subprocess.Popen([sys.executable, "-u", str(ROOT / "lab" / "lab.py"), "--dns-port", str(DNS_PORT)],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=ROOT / "lab")
    lines = []
    t0 = time.time()
    while time.time() - t0 < 60:
        ln = proc.stdout.readline()
        if not ln:
            break
        lines.append(ln.rstrip())
        print("  lab|", ln.rstrip())
        if "V6Lab READY" in ln:
            return proc, lines
    raise SystemExit("lab failed to start:\n" + "\n".join(lines))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lab-running", action="store_true", help="do not start lab.py (already running)")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--label", default="V6Lab simulation")
    ap.add_argument("--out", default=str(ROOT / "docs" / "simulation"))
    a = ap.parse_args()

    print("=" * 78 + "\nV6Scope controlled simulation\n" + "=" * 78)
    proc = None
    log_path = ROOT / "lab" / "logs" / "access.log"
    log_offset = log_path.stat().st_size if log_path.exists() else 0
    if not a.lab_running:
        print("[1] Starting V6Lab (DNS + dual-stack HTTPS servers with deliberate IPv6 faults)")
        proc, lab_lines = start_lab()
    else:
        lab_lines = []

    os.environ.update({
        "V6SCOPE_LAB_NAMESERVER": f"127.0.0.1:{DNS_PORT}",
        "V6SCOPE_EXTRA_CA": str(ROOT / "lab" / "certs" / "ca.pem"),
        # vantage self-test uses the lab's dual-stack control host
        "V6SCOPE_V6_ANCHORS": f"www.{L.ZONE}:{L.PORT}", "V6SCOPE_V4_ANCHORS": f"www.{L.ZONE}:{L.PORT}",
        "V6SCOPE_BROWSER": "0" if a.no_browser else "1",
    })
    bh = None if a.no_browser else prepare_browser_home()
    if bh:
        os.environ["V6SCOPE_BROWSER_HOME"] = bh

    from v6scope.config import settings  # imported after env is set
    from v6scope.db import DB
    from v6scope.scanner import Scanner

    db = DB(settings.db_path)
    sc = Scanner(settings, db)
    target = L.url("www", "/")
    print(f"[2] Scanning {target}")
    created = sc.create([target], a.label)
    sid = created["scans"][0]["id"]
    t0 = time.time()
    sc.run(sid, target, log=lambda m: print("   ", m))
    elapsed = round(time.time() - t0, 1)
    scan = db.get_scan(sid)
    by_url = {r["url"]: r for r in scan["resources"]}

    print("[3] Expected vs actual (answer key)")
    rows, passed = [], 0
    v6_vantage = bool(scan["vantage"]["v6"]["ok"])
    if not v6_vantage:
        print("    Scanner has no IPv6: the correct answer for transport-level cases is INCONCLUSIVE")
    for c in L.CASES:
        c = dict(c)
        if not v6_vantage and c["expected"] not in ("FAIL_DNS", "INCONCLUSIVE"):
            c["expected_with_v6"] = c["expected"]
            c["expected"] = "INCONCLUSIVE"
        r = by_url.get(c["url"])
        actual = r["ipv6_class"] if r else "NOT_DISCOVERED"
        v4ok = bool(r and r["v4"].get("ok"))
        ok = actual == c["expected"] and v4ok == c["expected_v4"]
        passed += ok
        rows.append({**c, "discovered": bool(r), "actual": actual, "v4_ok": v4ok, "match": ok,
                     "comparison": r["comparison"] if r else None,
                     "v6_fail_stage": r["v6"].get("fail_stage") if r else None,
                     "v6_error": r["v6"].get("error") if r else None,
                     "diagnosis": (r["diagnosis"] or {}).get("title") if r else None,
                     "browser_v4": (r["browser"] or {}).get("v4") if r else None,
                     "browser_v6": (r["browser"] or {}).get("v6") if r else None,
                     "seen_in": r["seen_in"] if r else []})
    print(f"    {'case':<4} {'expected':<13} {'actual':<13} {'IPv4':<5} match  resource")
    for x in rows:
        print(f"    {x['case']:<4} {x['expected']:<13} {x['actual']:<13} {'ok' if x['v4_ok'] else 'FAIL':<5} "
              f"{'YES' if x['match'] else 'NO ':<6} {x['url']}")
    extra = [r["url"] for r in scan["resources"] if r["url"] not in {c["url"] for c in L.CASES}]

    # independent evidence from the lab's own log
    fam_counts = Counter()
    if log_path.exists():
        with open(log_path) as f:
            f.seek(log_offset)
            for ln in f:
                try:
                    e = json.loads(ln)
                except Exception:
                    continue
                if e.get("proto") == "http":
                    fam_counts[(e["host"], f"IPv{e['family']}", e["client"], e["status"])] += 1
                elif e.get("proto") == "dns":
                    fam_counts[(e["qname"], "DNS " + e["qtype"], "query", e["rcode"])] += 1

    vant = scan["vantage"]
    result = {
        "scan_id": sid, "target": target, "elapsed_s": elapsed,
        "ran_at": scan["finished_at"], "host_kernel": os.uname().release, "hostname": os.uname().nodename,
        "vantage": {"v4": vant["v4"]["ok"], "v6": vant["v6"]["ok"],
                    "v6_detail": vant["v6"].get("detail")},
        "discovery_method": scan["discovery"].get("method"),
        "browser_views": {k: {kk: v.get(kk) for kk in ("request_count", "failed_count", "load_ms", "iterations", "page_error")}
                          for k, v in (scan["discovery"].get("views") or {}).items()},
        "resources_discovered": len(scan["resources"]), "unexpected_resources": extra,
        "cases_passed": passed, "cases_total": len(rows), "cases": rows,
        "summary": scan["summary"],
        "lab_log_counts": [{"name": k[0], "kind": k[1], "client": k[2], "result": k[3], "count": n}
                           for k, n in sorted(fam_counts.items())],
    }
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    jp = out / f"simulation-{stamp}.json"
    jp.write_text(json.dumps(result, indent=2, default=str))
    (out / "latest.json").write_text(json.dumps(result, indent=2, default=str))
    print(f"[4] {passed}/{len(rows)} cases match the answer key "
          f"(vantage IPv6 {'available' if result['vantage']['v6'] else 'NOT available'}); "
          f"scan {sid} took {elapsed}s; evidence → {jp}")
    if proc:
        proc.terminate()
    return 0 if passed == len(rows) else 1


if __name__ == "__main__":
    sys.exit(main())
